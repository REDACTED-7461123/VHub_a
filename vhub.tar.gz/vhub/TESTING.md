# Verification record

Date: 2026-11-02. Tests ran with Python 3.12, the pinned Python packages, and FFmpeg 6.1.1 on Linux.

## Automated checks

13 unittest cases pass. The suite creates actual H.264/AAC MP4 and FFV1/PCM MKV fixtures with FFmpeg and covers:

- Recursive indexing, UTF-8 case-insensitive search, exact folder filtering and pagination.
- Metadata and real JPEG thumbnail generation.
- Original and converted video streaming, byte ranges, suffix ranges, HEAD, If-Range and HTTP 416 responses.
- Cross-origin mutation rejection, read-only source API, symlink exclusion and path traversal rejection.
- Catalog preservation during missing/empty mounts and interrupted directory walks.
- Modified-file detection, stable IDs for unchanged paths, removed-file handling, and recently modified file deferral.
- Actual MKV-to-H.264/AAC MP4 conversion, duplicate queue suppression, cache clearing restrictions, and original-byte preservation.
- Sidecar SRT conversion to WebVTT and subtitle traversal rejection.
- Interrupted-job recovery on app restart.
- Next-video lookup beyond the first 100 files in a collection.

JavaScript passes `node --check`. Shell scripts pass `bash -n`. Python source compiles. Both Compose files parse as YAML and specify read-only media mounts. Gunicorn accepts its configuration and imports the application with `--check-config`.

## Browser checks

The real Flask app was opened in Chrome using generated demo video fixtures. Checked:

- Empty state and populated thumbnail grid layout.
- Search returning the matching card.
- Favorites toggling and a filtered favorites view.
- Original video metadata loading and playback time advancing.
- A sidecar subtitle track attached to the player.
- Browser conversion request progressing to a selectable compatible copy.
- The compatible copy loading as a video with the expected duration.
- Continue-watching listing and restoring the saved playback position after closing/reopening.

The demonstration media and preview environment are deliberately excluded from the delivered archive. The shipped app starts with the user's real NAS library.

## Environment boundaries

- Docker Engine/daemon is unavailable in the development workspace. The Docker image has **not been built or run here**, and Compose has not been executed against a Docker daemon. YAML validation is not a substitute for container integration testing.
- Your Synology NAS and Ubuntu server were not reachable from this workspace. NFS permissions, mounting, firewall rules, startup after reboot and NAS outage behavior must be checked on your actual network. Unit tests simulate filesystem failures; they do not simulate a real NFS kernel client.
- The Dockerfile installs Debian Bookworm's FFmpeg; local media tests used the available FFmpeg 6.1.1. The used encoding options are supported by Bookworm's FFmpeg, but the container build/runtime remains unverified.
- Desktop Chrome was inspected; Safari, Firefox, mobile browsers, TV browsers, HDR and real high-bitrate media have not been certified.
- No large-library, many-client, GPU, or real-time-transcoding performance benchmark was performed. Conversion is a queued, complete-file operation.

## First-run acceptance check on Ubuntu

1. Run setup, check `docker compose ps`, and confirm the container becomes healthy.
2. Open the printed URL from another LAN device; confirm your folders/videos appear.
3. Play an MP4, seek forward, close it midway, and reopen it to confirm resume.
4. Queue one unsupported video, wait for the copy, and play the compatible version.
5. Add a completed video to the NAS, then use Scan now to confirm it appears.
6. Restart the container; verify the catalog persists and your browser retains favorites.
7. Confirm the container cannot create a file under `/media` and that the original NAS files are unchanged.
