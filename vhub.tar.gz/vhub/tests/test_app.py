import json
import os
from pathlib import Path
import shutil
import subprocess
import tempfile
import time
import unittest
from unittest.mock import patch

from vhub.app import create_app


class VHubTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.samples = tempfile.TemporaryDirectory()
        cls.mp4 = Path(cls.samples.name) / "sample.mp4"
        cls.mkv = Path(cls.samples.name) / "sample.mkv"
        subprocess.run(["ffmpeg", "-nostdin", "-loglevel", "error", "-f", "lavfi", "-i", "testsrc2=size=320x180:rate=12", "-f", "lavfi", "-i", "sine=frequency=440:sample_rate=44100", "-t", "2", "-c:v", "libx264", "-threads", "1", "-pix_fmt", "yuv420p", "-c:a", "aac", "-movflags", "+faststart", str(cls.mp4)], check=True)
        subprocess.run(["ffmpeg", "-nostdin", "-loglevel", "error", "-i", str(cls.mp4), "-c:v", "ffv1", "-threads", "1", "-c:a", "pcm_s16le", str(cls.mkv)], check=True)

    @classmethod
    def tearDownClass(cls):
        cls.samples.cleanup()

    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.media = self.root / "media"
        (self.media / "Science").mkdir(parents=True)
        (self.media / "Films").mkdir()
        self.file = self.media / "Science" / "Пример & Test.mp4"
        shutil.copyfile(self.mp4, self.file)
        shutil.copyfile(self.mkv, self.media / "Films" / "Legacy.mkv")
        for path in self.media.rglob("*"):
            if path.is_file():
                os.utime(path, (time.time()-120, time.time()-120))
        self.app = create_app(dict(TESTING=True, MEDIA_DIR=str(self.media), DATA_DIR=str(self.root / "data"), START_WORKERS=False))
        self.client = self.app.test_client()
        self.lib = self.app.extensions["library"]
        self.lib.scan()
        self.video = self.client.get('/api/videos?q=пример').json['items'][0]
        self.headers = {"X-VHub-Request": "1"}

    def tearDown(self):
        self.temp.cleanup()

    def test_index_search_folders_pagination(self):
        status = self.client.get('/api/status').json
        self.assertEqual(status['count'], 2)
        self.assertEqual(len(status['folders']), 2)
        self.assertEqual(self.client.get('/api/videos?q=ПРИМЕР').json['total'], 1)
        self.assertEqual(self.client.get('/api/videos?folder=Films').json['total'], 1)
        self.assertEqual(self.client.get('/api/videos?limit=1').json['pages'], 2)
        self.assertEqual(len(self.client.get('/api/videos?limit=1&page=2').json['items']), 1)
        self.assertEqual(self.client.get('/api/videos?page=no').status_code, 400)
        self.assertEqual(self.client.get('/api/videos?ids=').json['total'], 0)
        self.assertEqual(self.client.get('/api/videos?q=%25').json['total'], 0)
        self.assertGreater(self.video['duration'], 1)
        self.assertEqual(self.video['width'], 320)

    def test_range_seeking_head_and_if_range(self):
        path = '/media/' + self.video['id']
        response = self.client.get(path, headers={'Range':'bytes=5-99'})
        self.assertEqual(response.status_code, 206)
        self.assertEqual(response.data, self.file.read_bytes()[5:100])
        self.assertEqual(response.headers['Content-Range'], f'bytes 5-99/{self.file.stat().st_size}')
        response.close()
        response = self.client.get(path, headers={'Range':'bytes=-40'})
        self.assertEqual(response.data, self.file.read_bytes()[-40:])
        response.close()
        response = self.client.get(path, headers={'Range':'bytes=999999999-'})
        self.assertEqual(response.status_code, 416)
        self.assertEqual(response.headers['Content-Range'], f'bytes */{self.file.stat().st_size}')
        response = self.client.head(path)
        self.assertEqual(response.data, b'')
        self.assertEqual(int(response.headers['Content-Length']), self.file.stat().st_size)
        etag = response.headers['ETag']
        response.close()
        response = self.client.get(path, headers={'Range':'bytes=0-10', 'If-Range':etag})
        self.assertEqual(response.status_code, 206)
        response.close()
        response = self.client.get(path, headers={'Range':'bytes=0-10', 'If-Range':'"outdated"'})
        self.assertEqual(response.status_code, 200)
        response.close()

    def test_thumbnails_and_no_external_assets(self):
        response = self.client.get('/thumb/' + self.video['id'])
        self.assertEqual(response.mimetype, 'image/jpeg')
        self.assertTrue(response.data.startswith(b'\xff\xd8'))
        response.close()
        response = self.client.get('/')
        self.assertIn(b'VHub', response.data)
        self.assertIn("script-src 'self'", response.headers['Content-Security-Policy'])
        response.close()
        for name in ['index.html','style.css','app.js']:
            text = (Path(__file__).parents[1] / 'vhub' / 'static' / name).read_text()
            self.assertNotIn('https://', text)

    def test_read_only_api_and_cross_origin_mutations(self):
        self.assertEqual(self.client.post('/api/scan').status_code, 403)
        self.assertEqual(self.client.post('/api/scan', headers={**self.headers, 'Origin':'https://evil.example'}).status_code, 403)
        self.assertEqual(self.client.post('/api/scan', headers={**self.headers, 'Sec-Fetch-Site':'cross-site'}).status_code, 403)
        self.assertEqual(self.client.post('/api/scan', headers=self.headers).status_code, 202)
        self.assertEqual(self.client.delete('/media/' + self.video['id'], headers=self.headers).status_code, 405)

    def test_path_escape_and_symlinks(self):
        (self.media / 'escape.mp4').symlink_to(self.mp4)
        self.lib.scan()
        self.assertEqual(self.client.get('/api/status').json['count'], 2)
        with self.lib.db() as db:
            db.execute('UPDATE videos SET path=? WHERE id=?', ('../../etc/passwd',self.video['id']))
        self.assertEqual(self.client.get('/media/' + self.video['id']).status_code, 503)
        self.assertEqual(self.client.get('/api/videos/not-real').status_code, 404)

    def test_empty_or_missing_mount_preserves_catalog(self):
        moved = self.root / 'unavailable'
        self.media.rename(moved)
        self.lib.scan()
        self.assertEqual(self.client.get('/api/status').json['count'], 2)
        self.media.mkdir()
        self.lib.scan()
        self.assertEqual(self.client.get('/api/status').json['count'], 2)
        self.assertTrue(self.lib.snapshot()['error'])
        self.assertEqual(self.client.get('/healthz').status_code, 200)

    def test_partial_walk_preserves_catalog(self):
        def failed_walk(*args, **kwargs):
            kwargs['onerror'](PermissionError('disconnected'))
            return iter([])
        with patch('vhub.app.os.walk', failed_walk):
            self.lib.scan()
        self.assertEqual(self.client.get('/api/status').json['count'], 2)
        self.assertTrue(self.lib.snapshot()['error'])

    def test_changed_file_refresh_and_partial_download(self):
        old = self.video['signature']
        with self.file.open('ab') as handle:
            handle.write(b'updated')
        self.assertEqual(self.client.get('/media/' + self.video['id']).status_code, 503)
        self.lib.scan()  # Recently changed files are deliberately skipped.
        self.assertEqual(self.lib.get(self.video['id'])['signature'], old)
        os.utime(self.file, (time.time()-120, time.time()-120))
        self.lib.scan()
        self.assertNotEqual(self.lib.get(self.video['id'])['signature'], old)
        response = self.client.get('/media/' + self.video['id'])
        self.assertEqual(response.status_code, 200)
        response.close()

    def test_removed_file_and_stable_id(self):
        initial = self.video['id']
        self.lib.scan()
        self.assertEqual(self.client.get('/api/videos?q=пример').json['items'][0]['id'], initial)
        self.file.unlink()
        self.lib.scan()
        self.assertEqual(self.client.get('/api/status').json['count'], 1)
        self.assertEqual(self.client.get('/api/videos/' + initial).status_code, 404)

    def test_conversion_real_media_seek_and_cache_clear(self):
        video = self.client.get('/api/videos?folder=Films').json['items'][0]
        path = '/api/videos/' + video['id'] + '/convert'
        original = (self.media / video['path']).read_bytes()
        self.assertEqual(self.client.post(path, headers=self.headers).status_code, 202)
        self.client.post(path, headers=self.headers)
        self.assertEqual(self.lib.jobs.qsize(), 1)
        self.assertEqual(self.client.delete('/api/cache', headers=self.headers).status_code, 409)
        work = self.lib.jobs.get_nowait()
        self.lib.convert(work)
        self.lib.jobs.task_done()
        conversion = self.lib.conversion(video)
        self.assertEqual(conversion['state'], 'ready', conversion)
        metadata = self.lib.probe(self.lib.converted_path(video))
        self.assertEqual(metadata['codec'], 'h264')
        self.assertEqual(metadata['audio'], 'aac')
        response = self.client.get('/media/' + video['id'] + '?version=compatible', headers={'Range':'bytes=0-99'})
        self.assertEqual(response.status_code, 206)
        self.assertEqual(response.mimetype, 'video/mp4')
        response.close()
        self.assertEqual((self.media / video['path']).read_bytes(), original)
        self.assertEqual(self.client.delete('/api/cache', headers=self.headers).status_code, 200)
        self.assertFalse(self.lib.converted_path(video).exists())

    def test_subtitles_srt_vtt_and_traversal(self):
        srt = self.file.with_suffix('.en.srt')
        srt.write_text('1\n00:00:00,000 --> 00:00:01,900\nHello from VHub\n', encoding='utf-8')
        detail = self.client.get('/api/videos/' + self.video['id']).json
        self.assertEqual(detail['subtitles'][0]['label'], 'en')
        response = self.client.get('/subtitles/' + self.video['id'], query_string={'file':srt.name})
        self.assertEqual(response.mimetype, 'text/vtt')
        self.assertIn(b'WEBVTT', response.data)
        self.assertIn(b'Hello from VHub', response.data)
        response.close()
        self.assertEqual(self.client.get('/subtitles/' + self.video['id'] + '?file=../../etc/passwd').status_code, 404)

    def test_restart_marks_interrupted_jobs_failed(self):
        self.lib.enqueue(self.video)
        app2 = create_app(dict(TESTING=True, MEDIA_DIR=str(self.media), DATA_DIR=str(self.root / 'data'), START_WORKERS=False))
        self.assertEqual(app2.extensions['library'].conversion(self.video)['state'], 'failed')

    def test_next_video_beyond_first_page(self):
        with self.lib.db() as db:
            for i in range(130):
                video_id = f'{i:024x}'
                db.execute('INSERT INTO videos(id,path,title,search,folder,size,mtime_ns,added,signature) VALUES(?,?,?,?,?,?,?,?,?)',
                           (video_id,f'Collection/{i:03}.mp4',f'{i:03}',str(i),'Collection',100,1,time.time(),'test'))
        response = self.client.get('/api/videos/' + f'{120:024x}' + '/next')
        self.assertEqual(response.json['item']['title'], '121')
        response = self.client.get('/api/videos/' + f'{129:024x}' + '/next')
        self.assertIsNone(response.json['item'])


if __name__ == '__main__':
    unittest.main()
