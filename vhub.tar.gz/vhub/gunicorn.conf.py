# A single process owns the scan/conversion queues. Do not increase workers.
bind = "0.0.0.0:8080"
workers = 1
worker_class = "gthread"
threads = 8
timeout = 120
graceful_timeout = 30
keepalive = 5
limit_request_line = 8190
accesslog = None
errorlog = "-"
loglevel = "info"
preload_app = False
