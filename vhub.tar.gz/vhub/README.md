# VHub

A small YouTube-style library for videos on your local network. Ubuntu runs the application; your Synology NAS at **192.168.1.66** stores the originals.

**Start here:** enable read-only NFS access on Synology, install Docker on Ubuntu, then run `sudo ./setup.sh`. The setup script asks for your real shared-folder export path and Ubuntu LAN address, and prints the browser URL.

This archive contains the **complete source, Dockerfile and Docker Compose deployment**, not a prebuilt Docker image. The first build downloads Python, FFmpeg and Python packages. Once built, VHub requires **no internet access**. To prepare installation elsewhere with poor/no internet, use the offline bundle instructions below.

## What is included

- Responsive thumbnail grid, folder collections, search, sorting and paginated browsing.
- Browser video playback, seek support, native fullscreen and playback controls.
- Favorites and automatic resume, saved separately in each browser (up to 200 favorites and 200 recent progress records).
- Recursive indexing at startup, every 15 minutes, and from **Library settings → Scan now**.
- Automatic FFmpeg previews; damaged files get a fallback thumbnail.
- On-demand H.264/AAC MP4 compatible copies for videos your browser cannot play.
- Sidecar UTF-8 `.srt` and `.vtt` subtitle tracks.
- Read-only NAS access. Metadata, previews and converted copies stay on Ubuntu.
- No cloud account, telemetry, external font, CDN, or runtime package downloads.

The app is intended for a **trusted home LAN**. It has no login or per-user permissions; every client that can reach the web port can browse, watch, rescan and request conversions. Do not forward its port to the internet. Browser histories are local, not shared accounts.

## 1. Prepare the machines

Recommended target: a 64-bit Ubuntu Server installation with rootful Docker Engine and Docker Compose v2. Ubuntu 22.04 or 24.04 LTS are straightforward targets. The Dockerfile can be built natively for amd64 or arm64; an offline image must match your server's architecture.

Reserve the NAS address **192.168.1.66** and the Ubuntu server's address in your router's DHCP settings. Use wired Ethernet between the server, NAS and router when possible. No internet connection is needed for streaming.

On Ubuntu, find the LAN address used to reach the NAS:

```bash
ip -4 route get 192.168.1.66
```

Use the address after `src` in the output. You will enter this actual address in DSM and the setup script. It is the Ubuntu address, not `192.168.1.66`.

Direct playback needs little CPU; conversions are much heavier. Start with at least 2 CPU cores, 2 GB RAM and sufficient local disk space. Default converted-copy allowance is 20 GiB, plus thumbnails/database; conversion also requires at least 1 GiB of free space. Long libraries need time for their initial scan. These are starting guidelines, not a measured capacity guarantee.

## 2. Configure the Synology NAS

Open DSM at [http://192.168.1.66:5000](http://192.168.1.66:5000), or your existing DSM HTTPS address.

1. Open **Control Panel → File Services → NFS**. Enable NFS. Select a maximum protocol of NFSv3 or newer and apply. This project deliberately mounts with NFSv3 for broad Synology compatibility.
2. Open **Control Panel → Shared Folder**, select the folder containing your videos, then **Edit → NFS Permissions → Create**.
3. Configure this rule:

| Setting | Value |
| --- | --- |
| Hostname or IP | The Ubuntu server's exact LAN IP found above |
| Privilege | **Read only** |
| Squash | **Map all users to admin** |
| Security | `sys` |
| Allow non-privileged ports | Leave disabled initially |
| Access mounted subfolders | Only needed if this share actually contains other mounted filesystems |

The UID mapping makes the container's non-root user able to read the share; the **read-only NFS rule** prevents writes. Restrict the rule to the single Ubuntu host, not `*` or the entire subnet. If you already manage consistent UID/GID permissions, you can use that existing mapping instead.

4. Copy the **Mount path** shown by DSM's NFS Permissions panel. A common example is `/volume1/video`; it might instead be `/volume2/Videos` or another path. **The correct path cannot be determined from the NAS address alone.** `setup.sh` asks for it.
5. If DSM's firewall is enabled, allow its built-in NFS/file-service rules from the Ubuntu IP only. NFSv3 uses the NFS and RPC-related services, so opening just port 2049 might be insufficient. Do not create router port-forwarding rules.

Files can remain in nested folders. For example, a video under `Courses/Python` appears in the `Python` collection, with its full path visible in the sidebar tooltip and player. Collections correspond to exact containing folders, rather than recursive parent filters. Symlinks and Synology's `@eaDir` and recycle folders are ignored.

Reference: [Synology NFS settings](https://kb.synology.com/index.php/en-us/DSM/help/DSM/AdminCenter/file_winmacnfs_nfs?version=7), [Synology permissions and UID mapping](https://kb.synology.com/en-us/DSM/tutorial/What_can_I_do_to_access_mounted_folders_NFS), [NFS troubleshooting](https://kb.synology.com/en-ca/DSM/tutorial/I_cannot_mount_shared_folders_via_NFS_what_should_I_do). DSM labels vary slightly by version.

## 3. Install Docker and start VHub

Copy `vhub.tar.gz` onto Ubuntu. Run these commands in the directory containing it:

```bash
tar -xzf vhub.tar.gz
cd vhub
sudo ./scripts/install-docker-ubuntu.sh
sudo ./setup.sh
```

The optional installer follows Docker's Ubuntu apt repository approach, installs `nfs-common` and Python 3, and starts Docker. It requires internet. It leaves an existing Docker installation intact and stops if it detects conflicting packages. For an existing nonstandard installation, follow [Docker's official Ubuntu guide](https://docs.docker.com/engine/install/ubuntu/) instead. Do not run a fresh installer blindly over an existing container host.

If Docker and Compose are already installed:

```bash
sudo apt-get update
sudo apt-get install -y nfs-common python3
sudo ./setup.sh
```

Setup prompts for the NAS address (defaults to `192.168.1.66`), the Ubuntu address (auto-detected), the exact NAS export path, and a web port (defaults to `8080`). It writes `.env`, builds the image if necessary, and starts the service. **Open the printed URL from another device on the same LAN.** You do not open the NAS's address to watch VHub; you open Ubuntu's address.

Docker mounts the NFS export itself. No Ubuntu `/etc/fstab` edit, host mount script or NAS password is needed for this NFS deployment. Both the NFS mount and the container volume are read-only. The web port is bound to the selected Ubuntu LAN address.

The Dockerfile runs the app as UID/GID `10001:10001` with no additional capabilities. The writable `vhub_data` volume is initialized with the correct ownership. The container root filesystem is read-only.

Check startup:

```bash
sudo docker compose ps
sudo docker compose logs --tail=100 -f
```

Exit log viewing with Ctrl-C; this does not stop VHub. New videos are listed before all thumbnails finish. Files changed in the last 30 seconds are skipped until the next scan to reduce interference with downloads. For long downloads, use a temporary extension such as `.part` and rename to `.mp4` when complete.

Docker-published ports have their own firewall behavior and may bypass ordinary UFW rules; do not rely solely on a UFW allow/deny rule. The selected LAN bind address, network/router isolation, and Docker-aware firewall rules control reachability. See [Docker's firewall notes](https://docs.docker.com/engine/install/ubuntu/#firewall-limitations).

## 4. Playback and subtitles

Open any card, then press the player's Play button. Browsers generally handle MP4 with H.264 video/AAC audio; WebM support depends on codecs and browser. A filename ending in `.mp4` does not guarantee the contained codecs are supported. MKV/AVI/HEVC/DTS content often needs conversion.

If the original does not play, or has no sound:

1. Click **Create compatible copy** in the player.
2. Wait for conversion to complete; its progress is shown there and in Library settings.
3. Select **Compatible copy** from the Playback menu and press Play.

Conversion is intentionally **not live transcoding**: the complete copy must finish before playback. One job runs at a time, with up to ten additional queued jobs and two FFmpeg threads by default. It produces an SDR-oriented H.264/AAC MP4 with at most a 1920 × 1080 frame, stereo audio, and the first video/audio streams. Direct playback keeps the original quality. GPU acceleration, HDR tone mapping, embedded subtitle extraction, alternate audio selection, playlists and synchronized accounts are not implemented in this version.

Converting an HDR source can produce incorrect colors because tone mapping is not implemented. Use a browser/device that supports the original or prepare an SDR copy separately. Source files are never overwritten.

Use matching subtitle filenames next to the video, for example:

```text
Lecture.mp4
Lecture.en.srt
Lecture.ru.vtt
```

The tracks appear in the native player's subtitle menu. SRT is converted to WebVTT on demand. Embedded MKV subtitles and image-based subtitles are not exposed. Browser-native controls differ slightly across Chrome, Firefox and Safari; the included automated media tests do not certify every device/browser codec combination.

Favorites/progress are stored in localStorage for the current browser and origin. Clearing browser data removes them. A different device, browser, hostname, or web port has separate history. There is no server-side sync. Shared links use the page's `#watch=…` fragment.

## 5. Operation and storage

| Item | Location |
| --- | --- |
| Original videos | NAS NFS export, mounted at `/media` read-only |
| Catalog | `vhub_data` Docker volume: `/data/library.sqlite3` |
| Previews | `/data/thumbnails` in the same local volume |
| Compatible copies | `/data/converted` in the same local volume |
| Converted sidecar subtitles | `/data/subtitles` in the same local volume |
| Favorites/resume | Browser localStorage |

Settings in `.env`:

| Variable | Default | Purpose |
| --- | --- | --- |
| `NAS_ADDRESS` | `192.168.1.66` | NAS IP |
| `NAS_EXPORT` | Set during setup | Exact DSM NFS mount path |
| `VHUB_BIND_IP` | Set during setup | Ubuntu IP on which the site listens |
| `VHUB_PORT` | `8080` | Browser port |
| `SCAN_INTERVAL` | `900` | Seconds between scans; minimum 60 |
| `CACHE_GB` | `20` | Compatible-copy allowance in GiB; minimum 0.1 |
| `FFMPEG_THREADS` | `2` | Conversion/decoder thread limit; 1–16 |

After changing ordinary settings, run:

```bash
sudo docker compose up -d --no-build --pull never
```

**Changing NAS_ADDRESS or NAS_EXPORT needs the special mount procedure below.** A named NFS volume retains its original mount options.

Useful commands:

```bash
# Stop; keep the catalog and generated files.
sudo docker compose down

# Start again without internet or rebuilding.
sudo docker compose up -d --no-build --pull never

# Rebuild after editing application source (may need internet).
sudo docker compose build
sudo docker compose up -d --no-build --pull never

# Review your concrete configuration.
sudo docker compose config
```

Do not use `docker compose down -v` unless you intend to remove the local catalog and all generated copies. It does not delete the read-only NAS originals, but it discards local VHub data.

Use **Library settings → Clear cache** to delete compatible copies. This does not delete source videos or thumbnails. It is disabled by the server while conversions are queued/running. No automatic eviction interrupts a compatible copy being watched. Old copies of removed/replaced NAS files remain in the conversion cache until you clear it; they count against the allowance.

The cache allowance applies to converted MP4s, including in-progress files; it is checked about once per second, so a short overshoot is possible. It is not a filesystem quota. Thumbnail and subtitle storage is separate and should be included in free-space monitoring. Interrupted conversions become failed jobs on restart and can be queued again.

## 6. Installation with no internet on Ubuntu

The source archive alone is **not** a complete offline installer. Prepare the image on another internet-connected Linux machine with Docker, using the same CPU architecture as the Ubuntu server:

```bash
tar -xzf vhub.tar.gz
cd vhub
sudo ./scripts/make-offline-bundle.sh
```

This writes `vhub-offline.tar.gz` one directory above `vhub`. It contains all application source plus `vhub-image.tar.gz`, exported with Docker's image save command. Copy the new archive to Ubuntu by USB or LAN. On Ubuntu:

```bash
tar -xzf vhub-offline.tar.gz
cd vhub
sudo ./setup.sh
```

Setup loads the bundled image, then starts it with `--no-build --pull never`. **Docker Engine, Compose, Python 3 and host NFS support must already be installed on Ubuntu.** Host operating-system packages are not bundled by this script. Prepare them while internet is available, or use the Ubuntu/Docker offline package installation process for your exact Ubuntu release and architecture. Inspect `IMAGE-INFO.txt` inside the offline bundle to verify the image architecture.

Reference: [Docker image save](https://docs.docker.com/reference/cli/docker/image/save/).

## 7. Change shares, use an existing mount, and back up

To change the NAS export after the first launch:

```bash
sudo docker compose down
sudo docker volume rm vhub_media
sudo ./setup.sh --configure
```

`vhub_media` is only the read-only NFS mount definition; removing it does not remove NAS files. Leave `vhub_data` intact. If Docker reports the volume is in use, stop the container using that volume before retrying. Paths identify videos, so renaming/moving a video changes its catalog ID and does not transfer its browser history.

If you prefer an existing Ubuntu SMB/NFS mount or a local disk, use **compose.local.yaml instead of compose.yaml**, not as an override. Mount your directory first and ensure UID 10001 has read/traverse permission; for SMB use a dedicated read-only Synology account and mount with `uid=10001,gid=10001,file_mode=0444,dir_mode=0555`. Put your real mount directory in `MEDIA_PATH` in `.env`. Run:

```bash
sudo docker compose -f compose.local.yaml build
sudo docker compose -f compose.local.yaml up -d --no-build --pull never
```

This alternate mode does not manage the host mount, credentials or boot ordering. Arrange the host mount before Docker starts the service, and restart/recreate the container after a manual remount. `create_host_path: false` prevents Docker from silently creating a missing path, but an empty pre-existing mountpoint can still look like an empty library.

Back up local VHub data consistently with the app stopped:

```bash
sudo docker compose stop
mkdir -p backups
sudo docker run --rm --user 0 --entrypoint python \
  --mount type=volume,source=vhub_data,target=/data,readonly \
  --mount type=bind,source="$PWD/backups",target=/backup \
  vhub:1.0.0 -c 'import tarfile; t=tarfile.open("/backup/vhub-data.tar.gz","w:gz"); t.add("/data",arcname="data"); t.close()'
sudo docker compose start
```

The backup contains the catalog, thumbnails and cached copies, not NAS originals or browser history. Save `.env` separately. To restore, stop VHub and extract the backup's `data` contents into `vhub_data`, preserving ownership (UID/GID 10001), then start it. The data is rebuildable from the NAS if you do not need cached copies.

## 8. Troubleshooting

**Docker cannot mount the share:** confirm the exact DSM export path and the single-host NFS rule. On Ubuntu, run:

```bash
showmount -e 192.168.1.66
sudo docker compose logs --tail=100
```

`showmount` is diagnostic only; some NAS firewall setups block its listing even when a particular export is mountable. Check the NAS is reachable and NFSv3/RPC services are permitted from Ubuntu. Docker must be rootful and host NFS support available.

**“Permission denied” or empty folders:** ensure the read-only NFS rule maps UID 10001 to an account allowed to read/traverse the shared folder. Do not use `chmod -R 777`. Check that you selected the share containing the actual videos. Symlinked video files/directories are intentionally ignored.

**The library reports a NAS error:** existing entries are retained after an incomplete scan or an unexpectedly empty mount; they do not prove the files are currently reachable. Original playback needs the NAS. Ready compatible copies can still play from Ubuntu. Restore NAS connectivity and rescan. If all videos were intentionally removed, the empty-mount safeguard retains the old catalog; stop VHub, back up `vhub_data`, then rebuild the catalog by removing only `library.sqlite3` and its `-wal`/`-shm` files from that local volume.

**A disconnected NAS makes reads slow:** the read-only NFS mount uses `soft,timeo=100,retrans=2`, so failed requests eventually return errors instead of indefinitely hanging application reads. This trades strict NFS retry behavior for responsiveness and can interrupt playback during a NAS/network outage. Never reuse those soft-mount settings for a writable database/share. Increase timeouts in Compose if your LAN is slow; then recreate `vhub_media` as described above.

**Cannot open the site from another device:** check the printed Ubuntu IP/port, `docker compose ps`, LAN routing, Wi-Fi client isolation, and Docker-aware firewall rules. The safe template default `127.0.0.1` only allows local access; run setup to select the actual LAN IP. If that IP changes, update `.env` and the Synology NFS rule.

**Preview missing:** thumbnails are generated sequentially. Wait for the first scan; check scan status. A corrupt or unsupported file retains a fallback image. The browser may cache a fallback until you reload the page. Videos modified within 30 seconds of scanning are deferred.

**Video has no sound / won't play:** try the compatible copy. Wait until it is ready and select it explicitly. Conversion uses only the first audio stream. Some TVs/browsers have limited HTML video support.

**Conversion fails:** check the cache allowance and free disk space. FFmpeg stops when the configured converted-file allowance is exceeded or free space falls below 1 GiB. Corrupt files, unsupported codecs or filesystem read errors can also fail. Server logs contain a bounded FFmpeg error tail. An individual job times out after 24 hours.

**Large library:** scan and thumbnail generation are sequential to limit NAS/CPU load. Browser cards load in pages of 24. Search is a case-folded substring over filenames and folder paths; it does not search inside video transcripts. Multiple clients share eight HTTP threads; this is a home-LAN app, not a large-scale streaming service.

## Development and verification

Stack: Python 3.12, Flask, Gunicorn, SQLite, FFmpeg, and plain HTML/CSS/JavaScript. One Gunicorn process owns background queues; **do not increase the worker count or run multiple replicas against the same data volume**. Its eight threads handle concurrent HTTP requests; one scan thread and one conversion thread do background work.

To run the tests on a development machine with Python and FFmpeg installed:

```bash
python3 -m venv .venv
.venv/bin/pip install -r requirements.txt
.venv/bin/python -m unittest discover -s tests -v
node --check vhub/static/app.js
bash -n setup.sh scripts/install-docker-ubuntu.sh scripts/make-offline-bundle.sh
```

See **TESTING.md** for actual verification results and untested environment boundaries. This project was not deployed to or tested against your NAS; its private LAN address is not reachable from the development workspace.
