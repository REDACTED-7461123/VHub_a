#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "${BASH_SOURCE[0]}")"
command -v python3 >/dev/null || { echo 'Install Python 3: sudo apt install python3'; exit 1; }
command -v docker >/dev/null || { echo 'Install Docker first: sudo ./scripts/install-docker-ubuntu.sh'; exit 1; }
docker compose version >/dev/null
docker info >/dev/null 2>&1 || { echo 'Docker is not accessible. Try: sudo ./setup.sh'; exit 1; }
if [[ ! -f .env || "${1:-}" == --configure ]]; then
  python3 scripts/configure.py
fi
docker compose config --quiet
if [[ -f vhub-image.tar.gz ]]; then
  echo 'Loading the bundled Docker image…'
  docker image load --input vhub-image.tar.gz
elif ! docker image inspect vhub:1.0.0 >/dev/null 2>&1; then
  echo 'Building the Docker image. This first build requires internet access.'
  docker compose build
fi
docker compose up -d --no-build --pull never
python3 scripts/configure.py --url
echo 'Check startup with: sudo docker compose ps'
echo 'Read logs with: sudo docker compose logs --tail=100 -f'
