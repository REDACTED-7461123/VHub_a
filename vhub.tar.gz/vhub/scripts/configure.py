#!/usr/bin/env python3
"""Write concrete local settings without guessing the Synology export path."""
import ipaddress
import json
from pathlib import Path
import subprocess
import sys

root = Path(__file__).resolve().parents[1]
env = root / ".env"


def address(prompt, default):
    while True:
        value = input(f"{prompt} [{default}]: ").strip() or default
        try:
            ipaddress.IPv4Address(value)
            return value
        except ValueError:
            print("Enter an IPv4 address.")


if "--url" in sys.argv:
    result = subprocess.run(["docker", "compose", "config", "--format", "json"], cwd=root, check=True, capture_output=True, text=True)
    config = json.loads(result.stdout)
    port = config["services"]["vhub"]["ports"][0]
    print(f"\nOpen http://{port.get('host_ip', '127.0.0.1')}:{port['published']} in a browser on your LAN.")
    print("The first library scan runs automatically. Thumbnails appear as they are generated.")
    sys.exit(0)

nas = address("Synology NAS address", "192.168.1.66")
try:
    route = subprocess.run(["ip", "-j", "route", "get", nas], capture_output=True, text=True, check=True)
    default_ip = json.loads(route.stdout)[0].get("prefsrc", "127.0.0.1")
except (OSError, subprocess.SubprocessError, ValueError, IndexError):
    default_ip = "127.0.0.1"
bind = address("Ubuntu LAN address (reserve this address in your router)", default_ip)
print(f"\nIn DSM, allow NFS READ-ONLY access from this Ubuntu IP: {bind}")
print("Copy the exact mount path from Shared Folder → Edit → NFS Permissions.")
print("It often looks like /volume1/video, but your actual path may differ.")
while True:
    export = input("Exact NFS mount path: ").strip()
    if export.startswith("/") and all(c not in export for c in '\n\r\x00$'):
        break
    print("Enter the absolute path shown in DSM; dollar signs are not supported by this setup helper.")
while True:
    port = input("Web port [8080]: ").strip() or "8080"
    if port.isdigit() and 1024 <= int(port) <= 65535:
        break
    print("Choose a port between 1024 and 65535.")
values = {"NAS_ADDRESS": nas, "NAS_EXPORT": export, "VHUB_BIND_IP": bind, "VHUB_PORT": port,
          "SCAN_INTERVAL": "900", "CACHE_GB": "20", "FFMPEG_THREADS": "2"}
env.write_text("# VHub local configuration\n" + "\n".join(f"{key}={json.dumps(value, ensure_ascii=False)}" for key, value in values.items()) + "\n")
env.chmod(0o600)
print("\nSaved .env. The NAS export will be mounted read-only by Docker.")
