#!/usr/bin/env bash
# Optional installer for a clean Ubuntu Server. Review before running as root.
set -euo pipefail
[[ $EUID == 0 ]] || { echo 'Run with sudo.'; exit 1; }
source /etc/os-release
[[ "$ID" == ubuntu ]] || { echo 'This installer is only for Ubuntu.'; exit 1; }
if command -v docker >/dev/null; then
  echo 'Docker is already installed; leaving the existing installation untouched.'
  docker compose version || { echo 'Install the Compose plugin for your existing Docker distribution.'; exit 1; }
  apt-get update
  apt-get install -y nfs-common python3
  exit 0
fi
for package in docker.io docker-compose docker-compose-v2 podman-docker containerd runc; do
  if dpkg-query -W -f='${Status}' "$package" 2>/dev/null | grep -q 'install ok installed'; then
    echo "Existing package $package may conflict. Follow https://docs.docker.com/engine/install/ubuntu/ to migrate your installation."
    exit 1
  fi
done
apt-get update
apt-get install -y ca-certificates curl nfs-common python3
install -m 0755 -d /etc/apt/keyrings
curl -fsSL https://download.docker.com/linux/ubuntu/gpg -o /etc/apt/keyrings/docker.asc
chmod a+r /etc/apt/keyrings/docker.asc
cat > /etc/apt/sources.list.d/docker.sources <<EOF
Types: deb
URIs: https://download.docker.com/linux/ubuntu
Suites: ${UBUNTU_CODENAME:-$VERSION_CODENAME}
Components: stable
Architectures: $(dpkg --print-architecture)
Signed-By: /etc/apt/keyrings/docker.asc
EOF
apt-get update
apt-get install -y docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin
systemctl enable --now docker
docker compose version
