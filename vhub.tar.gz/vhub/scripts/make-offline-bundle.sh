#!/usr/bin/env bash
# Run on a connected Linux computer with the SAME CPU architecture as Ubuntu.
set -euo pipefail
cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.."
project_dir="$PWD"
temp_dir=$(mktemp -d)
trap 'rm -rf -- "$temp_dir"' EXIT
docker build --tag vhub:1.0.0 .
mkdir "$temp_dir/vhub"
tar --exclude='./.env' --exclude='./.venv' --exclude='./.git' --exclude='./__pycache__' \
    --exclude='*/__pycache__' --exclude='./demo-media' --exclude='./demo-data' \
    --exclude='./node_modules' --exclude='./package.json' --exclude='*.tar' --exclude='*.tar.gz' \
    -cf - . | tar -xf - -C "$temp_dir/vhub"
docker image save vhub:1.0.0 | gzip -1 > "$temp_dir/vhub/vhub-image.tar.gz"
docker image inspect --format '{{.Os}}/{{.Architecture}} {{.Id}}' vhub:1.0.0 > "$temp_dir/vhub/IMAGE-INFO.txt"
tar -czf "$project_dir/../vhub-offline.tar.gz" -C "$temp_dir" vhub
echo "Created: $project_dir/../vhub-offline.tar.gz"
echo 'Copy this file to Ubuntu, extract it, then run sudo ./setup.sh.'
echo 'Docker Engine, Docker Compose, Python 3 and NFS host support must already be installed there.'
