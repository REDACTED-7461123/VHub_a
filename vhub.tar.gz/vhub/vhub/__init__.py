"""VHub — a small, entirely local video library."""
