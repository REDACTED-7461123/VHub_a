import hashlib
import json
import logging
import math
import mimetypes
import os
from pathlib import Path
import queue
import re
import shutil
import sqlite3
import subprocess
import tempfile
import threading
import time

from flask import Flask, abort, jsonify, request, send_file
from werkzeug.exceptions import HTTPException

LOG = logging.getLogger("vhub")
EXTENSIONS = {".mp4", ".m4v", ".mkv", ".webm", ".mov", ".avi", ".ts", ".mts", ".m2ts", ".mpeg", ".mpg", ".wmv", ".flv", ".ogv"}
IGNORED = {"@eaDir", "#recycle", "$RECYCLE.BIN", ".snapshot", "@Recycle"}
STATIC = Path(__file__).parent / "static"


class Library:
    def __init__(self, media, data, interval=900, cache_gb=20, threads=2):
        self.media = Path(media).resolve()
        self.data = Path(data).resolve()
        self.data.mkdir(parents=True, exist_ok=True)
        self.cache = self.data / "converted"
        self.thumbs = self.data / "thumbnails"
        self.subs = self.data / "subtitles"
        for folder in (self.cache, self.thumbs, self.subs):
            folder.mkdir(exist_ok=True)
        self.interval = max(60, interval)
        self.cache_limit = max(0.1, cache_gb) * 1024 ** 3
        self.threads = max(1, min(16, threads))
        self.scan_lock = threading.Lock()
        self.job_lock = threading.Lock()
        self.status_lock = threading.Lock()
        self.jobs = queue.Queue(maxsize=10)
        self.scan_event = threading.Event()
        self.status = dict(scanning=False, phase="idle", discovered=0, processed=0, error=None, last_scan=None)
        with self.db() as db:
            db.executescript("""
                PRAGMA journal_mode=WAL;
                CREATE TABLE IF NOT EXISTS videos (
                    id TEXT PRIMARY KEY, path TEXT UNIQUE NOT NULL, title TEXT NOT NULL,
                    search TEXT NOT NULL, folder TEXT NOT NULL, size INTEGER NOT NULL,
                    mtime_ns INTEGER NOT NULL, added REAL NOT NULL, duration REAL DEFAULT 0,
                    width INTEGER DEFAULT 0, height INTEGER DEFAULT 0,
                    codec TEXT DEFAULT '', audio TEXT DEFAULT '',
                    signature TEXT NOT NULL, probed INTEGER DEFAULT 0, error TEXT);
                CREATE INDEX IF NOT EXISTS videos_folder ON videos(folder);
                CREATE INDEX IF NOT EXISTS videos_added ON videos(added DESC);
                CREATE TABLE IF NOT EXISTS conversions (
                    id TEXT PRIMARY KEY, signature TEXT NOT NULL, state TEXT NOT NULL,
                    progress REAL DEFAULT 0, error TEXT, updated REAL NOT NULL);
            """)
            db.execute("UPDATE conversions SET state='failed', error='Server restarted. Queue this video again.' WHERE state IN ('queued','running')")
        for path in self.cache.glob("*.part.mp4"):
            path.unlink(missing_ok=True)

    def db(self):
        # Every operation owns its connection; the wrapper also closes it.
        return Connection(self.data / "library.sqlite3")

    def update_status(self, **values):
        with self.status_lock:
            self.status.update(values)

    def snapshot(self):
        with self.status_lock:
            return dict(self.status)

    def start(self):
        threading.Thread(target=self.scan_loop, daemon=True, name="scanner").start()
        threading.Thread(target=self.convert_loop, daemon=True, name="converter").start()

    def safe_path(self, relative):
        path = (self.media / relative).resolve()
        if not path.is_relative_to(self.media) or path == self.media or not path.is_file():
            raise FileNotFoundError("Video is unavailable on the NAS.")
        return path

    def get(self, video_id):
        with self.db() as db:
            row = db.execute("SELECT * FROM videos WHERE id=?", (video_id,)).fetchone()
        if row is None:
            raise KeyError(video_id)
        return dict(row)

    def current_path(self, video):
        path = self.safe_path(video["path"])
        st = path.stat()
        if st.st_size != video["size"] or st.st_mtime_ns != video["mtime_ns"]:
            self.scan_event.set()
            raise FileNotFoundError("File has changed. Rescan the library and try again.")
        return path

    @staticmethod
    def run(args, timeout):
        return subprocess.run(args, capture_output=True, timeout=timeout, check=True)

    def probe(self, path):
        result = self.run(["ffprobe", "-v", "error", "-protocol_whitelist", "file,pipe", "-show_format", "-show_streams", "-of", "json", str(path)], 45)
        info = json.loads(result.stdout)
        stream = next((s for s in info.get("streams", []) if s.get("codec_type") == "video" and not s.get("disposition", {}).get("attached_pic")), None)
        if not stream:
            raise ValueError("No video stream found")
        audio = next((s.get("codec_name", "") for s in info.get("streams", []) if s.get("codec_type") == "audio"), "")
        try:
            duration = float(info.get("format", {}).get("duration", stream.get("duration", 0)))
        except (ValueError, TypeError):
            duration = 0
        return dict(duration=duration if math.isfinite(duration) else 0, width=stream.get("width", 0), height=stream.get("height", 0), codec=stream.get("codec_name", ""), audio=audio)

    def thumb_path(self, video):
        return self.thumbs / (video["id"] + "-" + video["signature"] + ".jpg")

    def thumbnail(self, video, path):
        dest = self.thumb_path(video)
        if dest.exists():
            return
        seek = min(30, max(0, video["duration"] * 0.1))
        base = ["ffmpeg", "-nostdin", "-hide_banner", "-loglevel", "error", "-y", "-threads", str(self.threads), "-protocol_whitelist", "file,pipe"]
        for position in (seek, 0):
            try:
                self.run(base + ["-ss", str(position), "-i", str(path), "-map", "0:v:0", "-frames:v", "1", "-vf", "scale=480:270:force_original_aspect_ratio=decrease,pad=480:270:(ow-iw)/2:(oh-ih)/2", "-threads", "1", "-q:v", "4", str(dest)], 45)
                if dest.exists() and dest.stat().st_size:
                    return
            except (subprocess.SubprocessError, OSError):
                pass
        dest.unlink(missing_ok=True)

    def scan_loop(self):
        while True:
            self.scan_event.clear()
            self.scan()
            self.scan_event.wait(self.interval)

    def scan(self):
        if not self.scan_lock.acquire(blocking=False):
            return False
        self.update_status(scanning=True, phase="discovering", discovered=0, processed=0, error=None)
        try:
            if not self.media.is_dir():
                raise OSError("Media directory is unavailable. Check the NAS mount.")
            seen, pending, walk_errors = set(), [], []
            # Metadata pass first: large libraries become browsable before all thumbnails finish.
            for root, dirs, files in os.walk(self.media, followlinks=False, onerror=walk_errors.append):
                dirs[:] = [d for d in dirs if not d.startswith(".") and d not in IGNORED and not (Path(root) / d).is_symlink()]
                for name in files:
                    path = Path(root) / name
                    if path.suffix.lower() not in EXTENSIONS or name.startswith(".") or path.is_symlink():
                        continue
                    relative = path.relative_to(self.media).as_posix()
                    seen.add(relative)
                    try:
                        st = path.stat()
                        # A changing/download-in-progress file is left alone until a later scan.
                        if st.st_size == 0 or time.time() - st.st_mtime < 30:
                            continue
                        vid = hashlib.sha256(relative.encode()).hexdigest()[:24]
                        signature = hashlib.sha256(f"{st.st_size}:{st.st_mtime_ns}".encode()).hexdigest()[:16]
                        folder = str(Path(relative).parent)
                        folder = "" if folder == "." else folder
                        title = path.stem.replace("_", " ")
                        with self.db() as db:
                            db.execute("""INSERT INTO videos(id,path,title,search,folder,size,mtime_ns,added,signature)
                                VALUES(?,?,?,?,?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET
                                size=excluded.size, mtime_ns=excluded.mtime_ns,
                                probed=CASE WHEN signature=excluded.signature THEN probed ELSE 0 END,
                                error=CASE WHEN signature=excluded.signature THEN error ELSE NULL END,
                                signature=excluded.signature""",
                                (vid, relative, title, (title + " " + relative).casefold(), folder, st.st_size, st.st_mtime_ns, time.time(), signature))
                        video = self.get(vid)
                        if not video["probed"] or not self.thumb_path(video).exists():
                            pending.append(video)
                    except OSError as exc:
                        walk_errors.append(exc)
                    self.update_status(discovered=len(seen))
            if walk_errors:
                raise OSError(f"NAS scan could not finish ({len(walk_errors)} read errors). Existing entries were preserved.")
            # An unexpectedly empty mount never wipes an existing catalog.
            with self.db() as db:
                old = db.execute("SELECT id,path FROM videos").fetchall()
                if not seen and old:
                    raise OSError("No videos were found. Existing catalog preserved; check the NAS connection.")
                for row in old:
                    if row["path"] not in seen:
                        db.execute("DELETE FROM videos WHERE id=?", (row["id"],))
            self.update_status(phase="preparing previews")
            for i, video in enumerate(pending):
                try:
                    path = self.current_path(video)
                    metadata = self.probe(path)
                    self.current_path(video)
                    with self.db() as db:
                        db.execute("UPDATE videos SET duration=?,width=?,height=?,codec=?,audio=?,probed=1,error=NULL WHERE id=? AND signature=?",
                                   (*metadata.values(), video["id"], video["signature"]))
                    video.update(metadata)
                    self.thumbnail(video, path)
                except (OSError, ValueError, subprocess.SubprocessError) as exc:
                    LOG.warning("Cannot prepare %s: %s", video["path"], type(exc).__name__)
                    with self.db() as db:
                        db.execute("UPDATE videos SET probed=1,error=? WHERE id=?", ("Could not read this video. It may be incomplete or damaged.", video["id"]))
                self.update_status(processed=i + 1)
            self.cleanup_previews()
            self.update_status(last_scan=time.time(), phase="idle")
        except Exception as exc:
            LOG.exception("Library scan failed")
            self.update_status(error=str(exc), phase="idle")
        finally:
            self.update_status(scanning=False)
            self.scan_lock.release()
        return True

    def cleanup_previews(self):
        with self.db() as db:
            keys = {r["id"] + "-" + r["signature"] for r in db.execute("SELECT id,signature FROM videos")}
        for path in self.thumbs.glob("*.jpg"):
            if path.stem not in keys:
                path.unlink(missing_ok=True)

    def converted_path(self, video):
        return self.cache / (video["id"] + "-" + video["signature"] + ".mp4")

    def conversion(self, video):
        with self.db() as db:
            row = db.execute("SELECT state,progress,error,signature FROM conversions WHERE id=?", (video["id"],)).fetchone()
        if not row or row["signature"] != video["signature"]:
            return dict(state="none", progress=0, error=None)
        result = dict(row)
        result.pop("signature")
        if result["state"] == "ready" and not self.converted_path(video).exists():
            result.update(state="none", progress=0)
        return result

    def cache_size(self):
        total = 0
        for path in self.cache.glob("*.mp4"):
            try:
                total += path.stat().st_size
            except FileNotFoundError:
                pass  # The worker may atomically rename a completed file here.
        return total

    def enqueue(self, video):
        self.current_path(video)
        with self.job_lock:
            existing = self.conversion(video)
            if existing["state"] in {"ready", "running", "queued"}:
                return existing
            if self.jobs.full():
                raise ValueError("Conversion queue is full. Try again later.")
            if self.cache_size() >= self.cache_limit or shutil.disk_usage(self.data).free < 1024 ** 3:
                raise ValueError("Not enough cache space. Clear converted copies or increase the cache limit.")
            with self.db() as db:
                db.execute("INSERT OR REPLACE INTO conversions VALUES(?,?,?,?,?,?)", (video["id"], video["signature"], "queued", 0, None, time.time()))
            self.jobs.put_nowait(video)
        return self.conversion(video)

    def job_status(self, video, state, progress=0, error=None):
        with self.db() as db:
            db.execute("UPDATE conversions SET state=?,progress=?,error=?,updated=? WHERE id=? AND signature=?",
                       (state, progress, error, time.time(), video["id"], video["signature"]))

    def convert_loop(self):
        while True:
            video = self.jobs.get()
            try:
                self.convert(video)
            except Exception:
                LOG.exception("Unexpected conversion error")
                self.job_status(video, "failed", error="Conversion failed. Check server logs and retry.")
            finally:
                self.jobs.task_done()

    def convert(self, video):
        dest = self.converted_path(video)
        temporary = dest.with_suffix(".part.mp4")
        progress_file = temporary.with_suffix(".progress")
        log_file = temporary.with_suffix(".log")
        process = None
        self.job_status(video, "running")
        try:
            path = self.current_path(video)
            args = ["ffmpeg", "-nostdin", "-hide_banner", "-loglevel", "error", "-y",
                    "-threads", str(self.threads), "-protocol_whitelist", "file,pipe", "-i", str(path),
                    "-map", "0:v:0", "-map", "0:a:0?", "-sn", "-dn", "-map_metadata", "-1",
                    "-vf", "scale=w='min(1920,iw)':h='min(1080,ih)':force_original_aspect_ratio=decrease:force_divisible_by=2,setsar=1",
                    "-c:v", "libx264", "-preset", "veryfast", "-crf", "23", "-pix_fmt", "yuv420p", "-threads", str(self.threads),
                    "-c:a", "aac", "-b:a", "192k", "-ac", "2", "-movflags", "+faststart", "-progress", str(progress_file), str(temporary)]
            started = time.monotonic()
            with log_file.open("wb") as log:
                process = subprocess.Popen(args, stdout=subprocess.DEVNULL, stderr=log)
                while process.poll() is None:
                    time.sleep(1)
                    if self.cache_size() > self.cache_limit or shutil.disk_usage(self.data).free < 1024 ** 3:
                        raise ValueError("Conversion stopped: cache limit or low disk space. Clear converted copies or increase the limit.")
                    if time.monotonic() - started > 86400:
                        raise ValueError("Conversion stopped after 24 hours.")
                    if progress_file.exists() and video["duration"]:
                        with progress_file.open("rb") as progress:
                            progress.seek(max(0, progress_file.stat().st_size - 8192))
                            content = progress.read().decode(errors="replace")
                        values = re.findall(r"out_time_us=(\d+)", content)
                        if values:
                            percent = min(99, int(values[-1]) / (video["duration"] * 10000))
                            self.job_status(video, "running", round(percent, 1))
            if process.returncode != 0 or not temporary.exists() or temporary.stat().st_size == 0:
                LOG.warning("FFmpeg failed: %s", log_file.read_text(errors="replace")[-2000:])
                raise ValueError("FFmpeg could not convert this video. It may be damaged or use an unsupported format.")
            self.current_path(video)
            if self.cache_size() > self.cache_limit or shutil.disk_usage(self.data).free < 1024 ** 3:
                raise ValueError("Converted file exceeds the available cache space.")
            temporary.replace(dest)
            self.job_status(video, "ready", 100)
        except (OSError, ValueError, subprocess.SubprocessError) as exc:
            self.job_status(video, "failed", error=str(exc))
        finally:
            if process and process.poll() is None:
                process.kill()
                process.wait()
            for path in (temporary, progress_file, log_file):
                path.unlink(missing_ok=True)

    def subtitles(self, video):
        source = self.current_path(video)
        results = []
        for path in sorted(source.parent.iterdir()):
            if path.suffix.lower() not in {".vtt", ".srt"} or path.is_symlink():
                continue
            if path.stem == source.stem or path.stem.startswith(source.stem + "."):
                label = path.stem[len(source.stem):].lstrip(".") or "Subtitles"
                results.append({"file": path.name, "label": label[:80]})
        return results


class Connection:
    def __init__(self, path):
        self.connection = sqlite3.connect(path, timeout=30)
        self.connection.row_factory = sqlite3.Row

    def __enter__(self):
        return self.connection

    def __exit__(self, kind, value, traceback):
        try:
            if kind is None:
                self.connection.commit()
            else:
                self.connection.rollback()
        finally:
            self.connection.close()


def create_app(config=None):
    app = Flask(__name__, static_folder=str(STATIC), static_url_path="/static")
    app.config.update(MEDIA_DIR=os.getenv("MEDIA_DIR", "/media"), DATA_DIR=os.getenv("DATA_DIR", "/data"),
                      START_WORKERS=True, SCAN_INTERVAL=int(os.getenv("SCAN_INTERVAL", "900")),
                      CACHE_GB=float(os.getenv("CACHE_GB", "20")), FFMPEG_THREADS=int(os.getenv("FFMPEG_THREADS", "2")),
                      MAX_CONTENT_LENGTH=16384)
    if config:
        app.config.update(config)
    lib = Library(app.config["MEDIA_DIR"], app.config["DATA_DIR"], app.config["SCAN_INTERVAL"], app.config["CACHE_GB"], app.config["FFMPEG_THREADS"])
    app.extensions["library"] = lib
    if app.config["START_WORKERS"]:
        lib.start()

    @app.before_request
    def protect_mutations():
        if request.method not in {"GET", "HEAD", "OPTIONS"}:
            if request.headers.get("X-VHub-Request") != "1" or request.headers.get("Sec-Fetch-Site") == "cross-site":
                abort(403, "Use the VHub interface for this operation.")
            origin = request.headers.get("Origin")
            if origin and origin != request.host_url.rstrip("/"):
                abort(403, "Cross-origin operation blocked.")

    @app.after_request
    def headers(response):
        response.headers["X-Content-Type-Options"] = "nosniff"
        response.headers["X-Frame-Options"] = "DENY"
        response.headers["Referrer-Policy"] = "same-origin"
        response.headers["Content-Security-Policy"] = "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; media-src 'self' blob:; connect-src 'self'; object-src 'none'; base-uri 'none'; frame-ancestors 'none'"
        if request.path.startswith("/api/"):
            response.headers["Cache-Control"] = "no-store"
        return response

    @app.errorhandler(HTTPException)
    def http_error(error):
        response = error.get_response()
        response.data = json.dumps({"error": error.description})
        response.content_type = "application/json"
        return response

    @app.errorhandler(FileNotFoundError)
    def missing(error):
        return jsonify(error=str(error)), 503

    @app.errorhandler(KeyError)
    def unknown(error):
        return jsonify(error="Video not found."), 404

    @app.errorhandler(OSError)
    def io_error(error):
        LOG.exception("Storage error")
        return jsonify(error="Storage is unavailable. Check the NAS connection and Ubuntu disk space."), 503

    @app.get("/")
    def index():
        return send_file(STATIC / "index.html", max_age=0)

    @app.get("/healthz")
    def health():
        # Do not touch a disconnected NFS mount in the liveness check.
        with lib.db() as db:
            db.execute("SELECT 1")
        return jsonify(ok=True)

    @app.get("/api/status")
    def status():
        with lib.db() as db:
            counts = dict(db.execute("SELECT COUNT(*) AS count, COALESCE(SUM(size),0) AS bytes, COALESCE(SUM(duration),0) AS duration FROM videos").fetchone())
            folders = [dict(r) for r in db.execute("SELECT folder, COUNT(*) AS count FROM videos GROUP BY folder ORDER BY folder COLLATE NOCASE")]
            jobs = [dict(r) for r in db.execute("SELECT c.id,c.state,c.progress,c.error,v.title FROM conversions c JOIN videos v ON v.id=c.id AND v.signature=c.signature WHERE c.state IN ('running','queued') ORDER BY c.updated")]
        return jsonify(**counts, folders=folders, scan=lib.snapshot(), jobs=jobs, cache_bytes=lib.cache_size(), cache_limit=lib.cache_limit)

    @app.post("/api/scan")
    def scan():
        if not lib.snapshot()["scanning"]:
            lib.scan_event.set()
        return jsonify(ok=True), 202

    @app.get("/api/videos")
    def videos():
        q = request.args.get("q", "")[:250].casefold()
        folder = request.args.get("folder")
        try:
            page = max(1, int(request.args.get("page", 1)))
            limit = min(100, max(1, int(request.args.get("limit", 24))))
        except ValueError:
            abort(400, "Invalid page or limit.")
        sort = {"new": "added DESC, title COLLATE NOCASE", "name": "title COLLATE NOCASE", "duration": "duration DESC", "old": "added ASC, title COLLATE NOCASE"}.get(request.args.get("sort"), "added DESC, title COLLATE NOCASE")
        where, params = ["1=1"], []
        if q:
            where.append("instr(search, ?) > 0")
            params.append(q)
        if folder is not None:
            where.append("folder=?")
            params.append(folder)
        ids = request.args.get("ids")
        if ids is not None:
            selected = [s for s in ids.split(",") if re.fullmatch(r"[a-f0-9]{24}", s)][:500]
            if not selected:
                return jsonify(items=[], total=0, page=page, pages=0)
            where.append("id IN (" + ",".join("?" for _ in selected) + ")")
            params.extend(selected)
        clause = " AND ".join(where)
        with lib.db() as db:
            total = db.execute("SELECT COUNT(*) FROM videos WHERE " + clause, params).fetchone()[0]
            rows = db.execute("SELECT * FROM videos WHERE " + clause + " ORDER BY " + sort + " LIMIT ? OFFSET ?", params + [limit, (page - 1) * limit]).fetchall()
        return jsonify(items=[dict(r) for r in rows], total=total, page=page, pages=math.ceil(total / limit))

    @app.get("/api/videos/<video_id>")
    def video(video_id):
        item = lib.get(video_id)
        return jsonify(**item, conversion=lib.conversion(item), subtitles=lib.subtitles(item))

    @app.get("/thumb/<video_id>")
    def thumb(video_id):
        path = lib.thumb_path(lib.get(video_id))
        if path.exists():
            return send_file(path, mimetype="image/jpeg", max_age=3600, conditional=True)
        return send_file(STATIC / "placeholder.svg", mimetype="image/svg+xml", max_age=0)

    @app.get("/api/videos/<video_id>/next")
    def next_video(video_id):
        current = lib.get(video_id)
        with lib.db() as db:
            row = db.execute("""SELECT * FROM videos WHERE folder=? AND
                (title COLLATE NOCASE > ? OR (title COLLATE NOCASE = ? AND id > ?))
                ORDER BY title COLLATE NOCASE, id LIMIT 1""",
                (current["folder"], current["title"], current["title"], current["id"])).fetchone()
        return jsonify(item=dict(row) if row else None)

    @app.route("/media/<video_id>", methods=["GET", "HEAD"])
    def media(video_id):
        video = lib.get(video_id)
        if request.args.get("version") == "compatible":
            path = lib.converted_path(video)
            if lib.conversion(video)["state"] != "ready" or not path.exists():
                abort(404, "Compatible copy is not ready.")
            mime = "video/mp4"
        else:
            path = lib.current_path(video)
            mime = {".mp4": "video/mp4", ".m4v": "video/mp4", ".webm": "video/webm", ".mkv": "video/x-matroska", ".ts": "video/mp2t"}.get(path.suffix.lower(), mimetypes.guess_type(str(path))[0] or "application/octet-stream")
        response = send_file(path, mimetype=mime, conditional=True, max_age=0)
        response.headers["Accept-Ranges"] = "bytes"
        return response

    @app.get("/subtitles/<video_id>")
    def subtitles(video_id):
        video = lib.get(video_id)
        name = request.args.get("file", "")
        if name not in {s["file"] for s in lib.subtitles(video)}:
            abort(404, "Subtitle not found.")
        source = lib.current_path(video).parent / name
        if source.suffix.lower() == ".vtt":
            return send_file(source, mimetype="text/vtt", conditional=True)
        stat = source.stat()
        key = hashlib.sha256(f"{source}:{stat.st_size}:{stat.st_mtime_ns}".encode()).hexdigest()
        output = lib.subs / (key + ".vtt")
        if not output.exists():
            try:
                result = lib.run(["ffmpeg", "-nostdin", "-loglevel", "error", "-protocol_whitelist", "file,pipe", "-i", str(source), "-f", "webvtt", "pipe:1"], 20)
            except subprocess.SubprocessError:
                abort(422, "Could not read this subtitle. Use a UTF-8 SRT or WebVTT file.")
            with tempfile.NamedTemporaryFile(dir=lib.subs, delete=False) as temporary:
                temporary.write(result.stdout)
                temporary_name = Path(temporary.name)
            temporary_name.replace(output)
        return send_file(output, mimetype="text/vtt", conditional=True)

    @app.post("/api/videos/<video_id>/convert")
    def convert(video_id):
        try:
            result = lib.enqueue(lib.get(video_id))
        except ValueError as exc:
            return jsonify(error=str(exc)), 409
        return jsonify(result), 202

    @app.delete("/api/cache")
    def clear_cache():
        with lib.job_lock:
            with lib.db() as db:
                if db.execute("SELECT 1 FROM conversions WHERE state IN ('queued','running')").fetchone():
                    abort(409, "Wait for current conversions to finish before clearing the cache.")
                for path in lib.cache.glob("*.mp4"):
                    path.unlink(missing_ok=True)
                db.execute("DELETE FROM conversions")
        return jsonify(ok=True)

    return app
