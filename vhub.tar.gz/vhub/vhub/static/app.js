'use strict';
const $ = (selector) => document.querySelector(selector);
const escapeHTML = (value) => String(value ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const state = {view:'all', folder:null, query:'', sort:'new', page:1, pages:0, items:[], current:null, next:null, status:null, request:0};
let saved = {progress:{}, favorites:[]};
try {
  const parsed = JSON.parse(localStorage.getItem('vhub-v1'));
  if (parsed && parsed.progress && typeof parsed.progress === 'object' && Array.isArray(parsed.favorites)) {
    const validID = id => /^[a-f0-9]{24}$/.test(id);
    saved.favorites = parsed.favorites.filter(validID).slice(-200);
    saved.progress = Object.fromEntries(Object.entries(parsed.progress).filter(([id,p]) => validID(id) && p && Number.isFinite(p.position) && Number.isFinite(p.duration) && Number.isFinite(p.updated)).slice(-200));
  }
} catch {}
let storageWarned = false, lastSave = 0, toastTimer, searchTimer, conversionTimer, statusBusy = false;

function persist() {
  const entries = Object.entries(saved.progress).sort((a,b) => b[1].updated-a[1].updated).slice(0,200);
  saved.progress = Object.fromEntries(entries);
  saved.favorites = saved.favorites.slice(-200);
  try { localStorage.setItem('vhub-v1', JSON.stringify(saved)); }
  catch { if (!storageWarned) { toast('Browser storage is unavailable. Progress will only last for this visit.'); storageWarned = true; } }
}
function toast(message) { $('#toast').textContent = message; $('#toast').hidden = false; clearTimeout(toastTimer); toastTimer = setTimeout(() => $('#toast').hidden = true, 5000); }
async function api(path, method='GET') {
  const response = await fetch(path, {method, headers: method==='GET' ? {} : {'X-VHub-Request':'1'}});
  let data;
  try { data = await response.json(); } catch { throw new Error('The server did not return a valid response.'); }
  if (!response.ok) throw new Error(data.error || 'Request failed.');
  return data;
}
function bytes(size) { if (size < 1024) return `${size} B`; const units=['KB','MB','GB','TB']; let i=-1; do {size/=1024;i++;} while(size>=1024&&i<units.length-1); return `${size.toFixed(size>=100?0:1)} ${units[i]}`; }
function duration(value) { const n=Math.floor(value||0); return n>=3600 ? `${Math.floor(n/3600)}:${String(Math.floor(n/60)%60).padStart(2,'0')}:${String(n%60).padStart(2,'0')}` : `${Math.floor(n/60)}:${String(n%60).padStart(2,'0')}`; }
function folderLabel(path) { return path ? path.split('/').at(-1) : 'Unsorted'; }
function resumeIDs() { return Object.keys(saved.progress).filter(id=>{const p=saved.progress[id];return p.position>5&&!p.finished;}).sort((a,b)=>saved.progress[b].updated-saved.progress[a].updated); }
function progressBar(id) { const p=saved.progress[id]; if (!p?.duration) return ''; const percent=Math.min(100,Math.max(0,p.position/p.duration*100)); return `<div class="progress-track"><div class="progress-fill" style="width:${percent.toFixed(1)}%"></div></div>`; }
function card(video) {
  const favorite=saved.favorites.includes(video.id);
  const quality=video.height>=2160?'4K':video.height>=1080?'1080p':video.height>=720?'720p':'';
  return `<article class="video-card"><button class="video-link" data-play="${video.id}" aria-label="Watch ${escapeHTML(video.title)}"><div class="thumbnail"><img src="/thumb/${video.id}?v=${video.signature}" alt="" loading="lazy" decoding="async">${quality?`<span class="quality">${quality}</span>`:''}<span class="duration">${video.duration?duration(video.duration):'VIDEO'}</span>${progressBar(video.id)}</div><div class="video-info"><h3>${escapeHTML(video.title)}</h3><div class="video-meta"><span>${escapeHTML(folderLabel(video.folder))}</span><span class="meta-dot"></span><span>${escapeHTML(bytes(video.size))}</span></div></div></button><button class="favorite-button ${favorite?'saved':''}" data-favorite="${video.id}" aria-label="${favorite?'Remove from':'Add to'} favorites" aria-pressed="${favorite}">${favorite?'♥':'♡'}</button></article>`;
}
function updateNavigation() {
  document.querySelectorAll('[data-view]').forEach(b=>b.classList.toggle('active',state.view===b.dataset.view && state.folder===null));
  document.querySelectorAll('[data-folder]').forEach(b=>b.classList.toggle('active',state.folder===b.dataset.folder));
  document.querySelectorAll('[data-all]').forEach(b=>b.classList.toggle('active',state.folder===null));
  const label=state.folder!==null?folderLabel(state.folder):({all:'All videos',continue:'Continue watching',favorites:'Favorites'}[state.view]);
  $('#breadcrumb').textContent=label;
  $('#grid-title').textContent=state.query?'Search results':state.folder!==null?folderLabel(state.folder):({all:'Explore your library',continue:'Your next chapter',favorites:'The ones worth keeping'}[state.view]);
  if(state.view==='all'&&state.folder===null) $('#page-title').innerHTML='A little less online.<br>A lot more to watch.';
  else $('#page-title').textContent=label;
  $('#page-description').textContent=state.folder!==null?`A collection from ${state.folder || 'the root of your video folder'}.`:({all:'Everything you saved, all in one place. Make yourself at home.',continue:'Good stories are worth coming back to. Pick up where you left off.',favorites:'Your own shortlist, saved in this browser.'}[state.view]);
}
async function loadVideos(append=false) {
  const requestID=++state.request;
  updateNavigation();
  if(!append) {state.page=1;$('#video-grid').innerHTML='<div class="loading">Finding something good to watch…</div>';}
  $('#empty-state').hidden=true;$('#load-row').hidden=true;
  const params=new URLSearchParams({q:state.query,sort:state.sort,page:state.page,limit:24});
  if(state.folder!==null)params.set('folder',state.folder);
  if(state.view!=='all')params.set('ids',(state.view==='favorites'?saved.favorites:resumeIDs()).join(','));
  try {
    const data=await api(`/api/videos?${params}`);
    if(requestID!==state.request)return;
    state.items=append?[...state.items,...data.items]:data.items;state.pages=data.pages;
    $('#video-grid').innerHTML=state.items.map(card).join('');
    $('#result-count').textContent=`${data.total.toLocaleString()} ${data.total===1?'video':'videos'}`;
    $('#load-row').hidden=state.page>=data.pages;
    $('#empty-state').hidden=state.items.length>0;
    const noMatch=state.query||state.folder!==null;
    $('#empty-title').textContent=noMatch?'Nothing here just yet':state.view==='favorites'?'Keep your favorites close':state.view==='continue'?'A fresh start':'Your next watch starts here';
    $('#empty-description').textContent=noMatch?'Try a different search or collection.':state.view==='favorites'?'Tap the heart on a video to save it here.':state.view==='continue'?'Start watching a video and your progress will appear here.':'Connect your video folder, then scan the library. New videos will appear automatically.';
    $('#empty-scan').hidden=state.view!=='all'||Boolean(noMatch);
  } catch(error) {if(requestID!==state.request)return;$('#video-grid').innerHTML='';$('#empty-state').hidden=false;$('#empty-title').textContent='Can’t reach your library';$('#empty-description').textContent=error.message;$('#empty-scan').hidden=false;}
  loadContinue();
}
async function loadContinue() {
  const ids=resumeIDs().slice(0,3);
  const visible=state.view==='all'&&state.folder===null&&!state.query&&ids.length;
  $('#continue-section').hidden=!visible;
  if(!visible)return;
  try {
    const data=await api(`/api/videos?ids=${ids.join(',')}&limit=3`);
    if(state.view!=='all'||state.folder!==null||state.query)return;
    data.items.sort((a,b)=>ids.indexOf(a.id)-ids.indexOf(b.id));
    $('#continue-grid').innerHTML=data.items.map(v=>`<button class="continue-card" data-play="${v.id}"><div class="continue-thumb"><img src="/thumb/${v.id}?v=${v.signature}" alt="">${progressBar(v.id)}</div><div class="continue-copy"><strong>${escapeHTML(v.title)}</strong><p>${Math.max(1,Math.ceil((v.duration-(saved.progress[v.id]?.position||0))/60))} min left · Continue →</p></div></button>`).join('');
    $('#continue-section').hidden=data.items.length===0;
  } catch {$('#continue-section').hidden=true;}
}
function chooseView(view,folder=null) {state.view=view;state.folder=folder;state.query='';$('#search').value='';loadVideos();}
async function refreshStatus() {
  if(statusBusy)return;
  statusBusy=true;
  try {
    const data=await api('/api/status'), previous=state.status;state.status=data;
    $('#total-videos').textContent=data.count.toLocaleString();$('#nav-count').textContent=data.count.toLocaleString();$('#total-size').textContent=bytes(data.bytes);$('#total-hours').textContent=`${Math.round(data.duration/3600).toLocaleString()} hours`;
    $('#server-detail').textContent=data.scan.error?'Storage needs attention':data.scan.scanning?'Preparing your library':`${data.count.toLocaleString()} videos, ready when you are`;
    const banner=$('#scan-banner');banner.hidden=!data.scan.scanning&&!data.scan.error;banner.classList.toggle('error',Boolean(data.scan.error));
    banner.textContent=data.scan.error||`Scanning · ${data.scan.phase} · ${data.scan.discovered.toLocaleString()} files found${data.scan.processed?` · ${data.scan.processed.toLocaleString()} previews checked`:''}`;
    $('#folder-count').textContent=data.folders.length;
    const foldersChanged=!previous||JSON.stringify(previous.folders)!==JSON.stringify(data.folders);
    if(foldersChanged){
      $('#folder-nav').innerHTML=data.folders.map(f=>`<button class="folder-button" data-folder="${escapeHTML(f.folder)}" title="${escapeHTML(f.folder||'Unsorted')}"><span class="folder-icon">▱</span><span class="folder-name">${escapeHTML(folderLabel(f.folder))}</span><span class="folder-number">${f.count}</span></button>`).join('');
      $('#filter-chips').innerHTML='<button class="chip" data-all>All videos</button>'+data.folders.slice(0,8).map(f=>`<button class="chip" data-folder="${escapeHTML(f.folder)}">${escapeHTML(folderLabel(f.folder))}</button>`).join('');
      updateNavigation();
    }
    $('#cache-usage').textContent=`${bytes(data.cache_bytes)} used of ${bytes(data.cache_limit)}. Originals are never removed.`;
    $('#queue-list').innerHTML=data.jobs.map(j=>`<div class="queue-item">${escapeHTML(j.title)} · ${j.state==='queued'?'Queued':`${Math.round(j.progress)}% converted`}</div>`).join('');
    $('#scan-button').disabled=data.scan.scanning;$('#scan-button').textContent=data.scan.scanning?'Scanning…':'Scan now';
    if(previous && ((previous.scan.scanning&&!data.scan.scanning)||(!previous.count&&data.count))&&!$('#player-dialog').open) loadVideos();
  } catch {$('#server-detail').textContent='Server is unavailable';$('#scan-banner').hidden=false;$('#scan-banner').classList.add('error');$('#scan-banner').textContent='Connection lost. Check that your Ubuntu server is running.';}
  finally {statusBusy=false;}
}
function toggleFavorite(id) {
  const exists=saved.favorites.includes(id);saved.favorites=exists?saved.favorites.filter(x=>x!==id):[...saved.favorites,id];persist();
  document.querySelectorAll(`[data-favorite="${id}"]`).forEach(b=>{b.classList.toggle('saved',!exists);b.textContent=exists?'♡':'♥';b.setAttribute('aria-pressed',String(!exists));b.setAttribute('aria-label',exists?'Add to favorites':'Remove from favorites');});
  updatePlayerFavorite();
  if(state.view==='favorites')loadVideos();
}
function updatePlayerFavorite() {if(state.current)$('#player-favorite').textContent=saved.favorites.includes(state.current.id)?'♥ Saved':'♡ Favorite';}
function saveProgress(force=false) {
  const player=$('#player');if(!state.current||!Number.isFinite(player.duration)||player.currentTime<1)return;
  if(!force&&Date.now()-lastSave<5000)return;
  lastSave=Date.now();saved.progress[state.current.id]={position:player.currentTime,duration:player.duration,updated:Date.now(),finished:player.ended||(player.currentTime/player.duration>.97)};persist();
}
function updateConversion(video) {
  const c=video.conversion;
  const ready=c.state==='ready',working=['queued','running'].includes(c.state);
  $('#playback-mode').querySelector('[value="compatible"]').disabled=!ready;
  $('#convert-button').disabled=ready||working;
  $('#convert-button').textContent=ready?'Compatible copy ready':working?'Conversion in progress…':'Create compatible copy';
  $('#convert-status').textContent=c.state==='queued'?'Waiting in queue':c.state==='running'?`${Math.round(c.progress)}% converted`:c.state==='ready'?'Select “Compatible copy” to watch':c.state==='failed'?c.error:'';
}
function setSource(version, position=null) {
  const video=state.current,player=$('#player');if(!video)return;
  const start=position ?? (player.currentTime||saved.progress[video.id]?.position||0);
  player.pause();player.replaceChildren();
  player.src=`/media/${video.id}${version==='compatible'?'?version=compatible':''}`;
  player.poster=`/thumb/${video.id}?v=${video.signature}`;
  for(const sub of video.subtitles){const track=document.createElement('track');track.kind='subtitles';track.label=sub.label;track.src=`/subtitles/${video.id}?${new URLSearchParams({file:sub.file})}`;player.append(track);}
  $('#player-notice').hidden=true;
  player.onloadedmetadata=()=>{if(start>5&&start<player.duration-5)player.currentTime=start;};
  player.load();
}
async function openVideo(id) {
  if(state.current?.id===id&&$('#player-dialog').open)return;
  saveProgress(true);$('#player').pause();
  clearInterval(conversionTimer);
  const token=id;state.opening=token;
  try {
    const video=await api(`/api/videos/${id}`);if(state.opening!==token)return;
    state.current=video;
    $('#player-title').textContent=video.title;$('#player-meta').textContent=`${video.folder||'Unsorted'} · ${duration(video.duration)} · ${bytes(video.size)}${video.width?` · ${video.width} × ${video.height}`:''}${video.codec?` · ${video.codec.toUpperCase()}`:''}`;
    $('#playback-mode').value=video.conversion.state==='ready'?'compatible':'original';
    updateConversion(video);updatePlayerFavorite();setSource($('#playback-mode').value,saved.progress[video.id]?.finished?0:(saved.progress[video.id]?.position||0));
    if(!$('#player-dialog').open)$('#player-dialog').showModal();
    history.replaceState(null,'',`#watch=${id}`);
    if(video.error){$('#player-notice').textContent=video.error;$('#player-notice').hidden=false;}
    $('#next-row').hidden=true;state.next=null;
    const collection=await api(`/api/videos/${id}/next`);
    if(state.current?.id!==id)return;
    const next=collection.item;
    if(next){state.next=next;$('#next-title').textContent=next.title;$('#next-row').hidden=false;}
    conversionTimer=setInterval(refreshCurrent,3000);
  } catch(error){toast(error.message);}
}
async function refreshCurrent(){const id=state.current?.id;if(!id||document.hidden)return;try{const data=await api(`/api/videos/${id}`);if(state.current?.id!==id)return;state.current.conversion=data.conversion;updateConversion(data);}catch{}}
function closePlayer(){saveProgress(true);$('#player').pause();$('#player').removeAttribute('src');$('#player').replaceChildren();$('#player').load();$('#player').onloadedmetadata=null;state.current=null;state.opening=null;clearInterval(conversionTimer);history.replaceState(null,'',location.pathname+location.search);loadVideos();}
async function scan(){try{await api('/api/scan','POST');toast('Library scan requested.');setTimeout(refreshStatus,600);}catch(error){toast(error.message);}}

document.addEventListener('click',event=>{
  const target=event.target.closest('button');if(!target)return;
  if(target.dataset.play)openVideo(target.dataset.play);
  if(target.dataset.favorite)toggleFavorite(target.dataset.favorite);
  if(target.dataset.view)chooseView(target.dataset.view);
  if(target.hasAttribute('data-folder'))chooseView('all',target.dataset.folder);
  if(target.hasAttribute('data-all'))chooseView('all');
});
$('#search').addEventListener('input',()=>{clearTimeout(searchTimer);searchTimer=setTimeout(()=>{state.query=$('#search').value.trim();loadVideos();},250);});
$('#search-form').addEventListener('submit',event=>{event.preventDefault();clearTimeout(searchTimer);state.query=$('#search').value.trim();loadVideos();});
$('#sort').addEventListener('change',()=>{state.sort=$('#sort').value;loadVideos();});
$('#load-more').addEventListener('click',()=>{state.page++;loadVideos(true);});
$('#see-continue').addEventListener('click',()=>chooseView('continue'));
$('#settings-open').addEventListener('click',()=>{$('#settings-dialog').showModal();refreshStatus();});
$('#settings-close').addEventListener('click',()=>$('#settings-dialog').close());
$('#player-close').addEventListener('click',()=>$('#player-dialog').close());
$('#player-dialog').addEventListener('close',closePlayer);
$('#player-favorite').addEventListener('click',()=>{if(state.current)toggleFavorite(state.current.id);});
$('#player').addEventListener('timeupdate',()=>saveProgress());
$('#player').addEventListener('pause',()=>saveProgress(true));
$('#player').addEventListener('ended',()=>saveProgress(true));
$('#player').addEventListener('error',()=>{if(state.current){$('#player-notice').textContent='Playback could not start. Check the NAS connection, or create and select a compatible copy for this browser.';$('#player-notice').hidden=false;}});
$('#playback-mode').addEventListener('change',()=>{saveProgress(true);setSource($('#playback-mode').value);});
$('#convert-button').addEventListener('click',async()=>{if(!state.current)return;$('#convert-button').disabled=true;try{await api(`/api/videos/${state.current.id}/convert`,'POST');await refreshCurrent();refreshStatus();}catch(error){toast(error.message);$('#convert-button').disabled=false;}});
$('#play-next').addEventListener('click',()=>{if(state.next)openVideo(state.next.id);});
$('#scan-button').addEventListener('click',scan);$('#empty-scan').addEventListener('click',scan);
$('#clear-cache').addEventListener('click',async()=>{if(!confirm('Delete all compatible copies? Original NAS videos and thumbnails will stay. Active playback of a compatible copy may stop.'))return;try{await api('/api/cache','DELETE');toast('Compatible copies cleared.');refreshStatus();refreshCurrent();}catch(error){toast(error.message);}});
$('#clear-history').addEventListener('click',()=>{if(confirm('Remove all favorites and watch progress saved in this browser?')){saved={progress:{},favorites:[]};persist();loadVideos();updatePlayerFavorite();toast('Browser history reset.');}});
document.addEventListener('keydown',event=>{if(event.key==='/'&&!['INPUT','TEXTAREA','SELECT'].includes(document.activeElement.tagName)&&!$('#player-dialog').open&&!$('#settings-dialog').open){event.preventDefault();$('#search').focus();}});
document.addEventListener('visibilitychange',()=>{if(document.hidden)saveProgress(true);else refreshStatus();});
window.addEventListener('pagehide',()=>saveProgress(true));
window.addEventListener('hashchange',()=>{const match=location.hash.match(/^#watch=([a-f0-9]{24})$/);if(match)openVideo(match[1]);else if($('#player-dialog').open)$('#player-dialog').close();});
refreshStatus();loadVideos();setInterval(()=>{if(!document.hidden)refreshStatus();},5000);
const initialVideo=location.hash.match(/^#watch=([a-f0-9]{24})$/);if(initialVideo)openVideo(initialVideo[1]);
