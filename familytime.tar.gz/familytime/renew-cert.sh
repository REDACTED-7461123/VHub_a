#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "$0")"
umask 077
ip=$(sed -n 's/^FT_LAN_IP=//p' .env)
python3 -c 'import ipaddress,sys; ipaddress.IPv4Address(sys.argv[1])' "$ip"
tmp=$(mktemp -d ./tls/.issue-XXXXXX)
trap 'rm -rf -- "$tmp"' EXIT
openssl req -new -newkey rsa:2048 -nodes -subj "/CN=$ip" -keyout "$tmp/key" -out "$tmp/leaf.csr"
printf 'subjectAltName=IP:%s\nextendedKeyUsage=serverAuth\nbasicConstraints=critical,CA:FALSE\nkeyUsage=critical,digitalSignature,keyEncipherment\n' "$ip" > "$tmp/ext"
openssl x509 -req -in "$tmp/leaf.csr" -CA household-ca.crt -CAkey private/ca.key -set_serial "0x$(openssl rand -hex 16)" \
  -days 365 -sha256 -extfile "$tmp/ext" -out "$tmp/leaf.crt"
mv "$tmp/key" tls/server.key
mv "$tmp/leaf.crt" tls/server.crt
echo "Certificate issued. If the dashboard is running, run: docker compose restart dashboard"
