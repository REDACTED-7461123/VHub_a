# Familytime

Familytime runs the parent dashboard on Ubuntu and enforces one local standard account per Windows PC. Pair additional PCs from the same dashboard. Each device has its own schedule, website rules and usage totals. The dashboard works on a phone or computer on the household LAN.

## 1. Start the Ubuntu dashboard

You need Ubuntu with Docker Engine, the Docker Compose v2 plugin, OpenSSL and Python 3.9+ with system time-zone data. Use a regular account that can run Docker. Reserve the server’s LAN IPv4 address in your router. The first Docker build downloads the Python base image and pinned server dependencies. Once installed, all management, authentication, policy enforcement and reporting run locally.

Extract the archive, open a terminal in the directory containing the extracted familytime folder, and run:

```bash
cd familytime
bash setup.sh
```

Confirm the LAN address and household time zone, then set a parent password of at least 12 characters. Setup prints the HTTPS dashboard URL and creates **windows-client.zip** with the public household certificate and the server address. Keep the Ubuntu installation directory private. Only the public certificate and the generated Windows bundle should leave it.

If your extractor discarded Unix file permissions, run this inside the project before setup:

```bash
chmod +x setup.sh make-client.sh renew-cert.sh
```

Open the printed URL from your PC or phone. To trust the private HTTPS certificate, transfer **household-ca.crt** directly from the Ubuntu server and compare its SHA-256 fingerprint with the setup output. On a Windows parent PC, import it into **Current User → Trusted Root Certification Authorities**. On iOS install the certificate profile, then enable full trust under **Settings → General → About → Certificate Trust Settings**. On Android use the system certificate installer for a CA certificate. Browser or work-profile trust settings can vary. The Windows agent trusts its bundled certificate directly.

Keep TCP 8443 on the home LAN. No router port forward is required. Docker publishes the port on the selected IP. Check any Docker forwarding and firewall rules if the dashboard is unreachable. For access from outside the home, use your own authenticated VPN.

## 2. Pair the Windows PC

1. In the dashboard select **Pair a device**, enter its name, and create a 15-minute code. The code is displayed once. You can issue a new code for a pending device.
2. Set the desired limits and website rules. New devices start with a 120-minute daily budget, all-day access and an empty website blocklist.
3. Transfer **windows-client.zip** to the separate parent administrator account on the Windows PC. Download/install official **64-bit CPython 3.11 or newer for all users**, under Program Files, if needed. The agent uses only the Python standard library. An offline Python installer can be transferred with the ZIP.
4. Extract the entire bundle inside the parent’s private profile. In its **windows** directory, right-click **Install.cmd → Run as administrator**. Accept the server address, select the child’s local standard username, and enter the pairing code. All three prompts are interactive.
5. Fully close and reopen Chrome, Edge and Firefox once after installation. Subsequent policy changes apply while they are running. Allow around 15 seconds for a connected agent to receive a change and another report for dashboard confirmation.
6. Complete the verification steps in **docs/WINDOWS.md** before relying on restrictions. The generated Windows ZIP contains the same guide as **README-WINDOWS.md**.

**Installation choice.** Strict networking is the default. A Windows Firewall rule prevents applications running as the child from making direct non-loopback connections, including to the LAN. Their web traffic must use the device’s local proxy. Games, NAS access and apps that ignore proxies may lose connectivity. The proxy settings in the three managed browsers apply to every Windows account on that PC. The separate parent PC and phone are unaffected. If the child needs direct network apps, the Windows guide describes the weaker `-BrowserOnly` install option.

## Using the dashboard

| Screen | What you can do |
|---|---|
| Overview | See current device status, time available before the next cutoff, today’s active usage, Monday-to-date total and daily usage chart. Add 30 minutes, subtract 15, or enter a custom amount. |
| Time limits | Set each weekday’s total minutes and one allowed interval. Use 00:00–24:00 for all day. Set the limit to 0 for a day off. Split an overnight interval at midnight onto two days. |
| Website rules | Choose blocklist or allowlist. Enter one domain per line. A domain includes all its subdomains. Add or revoke an expiring allow exception. |
| History | Inspect daily totals and recent parent actions or reported restriction events. Select up to 366 days. An unreported day is labelled separately from a reported zero. |
| Device selector | Switch between independently paired PCs. To retire a PC, uninstall its agent first, then remove it from History. Removal deletes the device’s server history and revokes its token. |

Adjustments apply only to the current household date. For example, adding 30 minutes to a 90-minute day makes the budget 120 minutes. Subtracting time below the amount already used can restrict access immediately. Adjustments do not extend the allowed interval. While offline the dashboard displays the latest reported totals. Queued parent changes take effect on reconnection. The agent applies the most recently received schedule in the meantime.

### What counts as screen time

The service samples the child’s Windows sessions about every two seconds. An unlocked, connected session with input in the last five minutes counts. Locked, disconnected and sleeping intervals do not count. Several sessions for the same user count once. The idle cutoff means long periods of passive video playback or reading can be undercounted. On sessions where Windows supplies no last-input timestamp, the agent counts unlocked time. Sampling introduces a few seconds of uncertainty around transitions.

The server sends the household’s IANA time-zone data to the agent. Daily resets, weekday rules and charts follow that zone even if Windows displays another zone. Keep the system clocks accurate. Warnings appear at roughly five minutes and one minute before the budget or allowed interval ends. Abrupt parent changes and waking up after a cutoff can take effect without those warnings.

At a cutoff the service disables the *selected child account* and requests a session disconnect. If Windows refuses to disconnect that console, it requests sign-out, which can discard unsaved work. The service re-enables an account it disabled when time becomes available. Keep the separate parent administrator account enabled and its credentials private.

## How the pieces fit

- **Ubuntu** serves the static dashboard and HTTPS API with aiohttp. SQLite stores individual device policies, daily aggregates, adjustment and exception actions, expiring sessions, and hashed device credentials. The password uses scrypt with a random salt. Cookies are Secure, HttpOnly and SameSite=Strict. Parent writes require JSON and a custom request header. Login attempts are rate-limited.
- **Windows** runs an automatic LocalSystem service. Installation compiles its small C# service host using the .NET Framework compiler included on supported Windows PCs. The worker uses native WTS session information, sleep-excluding interrupt time and local account APIs. Program Files ACLs restrict the code, SQLite state, token and configuration to SYSTEM and administrators.
- **Synchronization** uses an outbound, server-validated HTTPS connection and a random per-device bearer token. No incoming agent control port is exposed to the LAN. The SQLite journal checkpoints cumulative totals. Retries and older reports merge by maximum for each device/date, avoiding double charging. New usage accrued during a request stays pending after its reply. A policy revision prevents stale open dashboard tabs from overwriting newer edits.
- **Website filtering** uses mandatory browser policies pointing at an HTTP proxy on 127.0.0.1:17841. The service checks destination hostnames for HTTP requests and HTTPS CONNECT tunnels. HTTPS contents remain encrypted. New rules and local exception expiry also close open tunnels to newly disallowed hosts. The agent uses its own direct, certificate-validated connection to Ubuntu.
- **Collected data** consists of daily active seconds, last report time, coarse state, configured policy and recent actions. The agent records service errors locally in a rotating log. There is no browser history, screenshot capture, key capture, or page-content log.

## Limits of enforcement

The supported target is an x64 Windows 10/11 desktop, a local standard child account and a separate local administrator. Test a currently supported Windows edition/build. Microsoft-account, Entra, domain and Family Safety managed identities are outside this release’s account-enforcement path. Browser coverage targets current desktop Chrome, Edge and Firefox with local machine proxy policies honored. Check each browser’s policy page on the real PC. Enterprise policy conflicts or profiles that ignore the proxy can leave the browser without connectivity in strict mode.

Allowlist mode starts with all hostnames denied. A site may need separate login, content delivery and media domains. Add only the dependencies it needs. An exception grants its domain and subdomains in either mode. Domain names can refer to public sites or household web servers on ordinary private LAN addresses. The proxy supports HTTP (80) and HTTPS (443). It rejects IP literals, loopback, link-local destinations and nonstandard ports. Plain HTTP supports fixed-length requests; chunked request uploads, plain HTTP protocol upgrades and Expect/Continue are rejected. Normal HTTPS traffic tunnels through transparently, including HTTPS uploads.

The filter controls connections by hostname. Cached/offline content, a webpage already rendered, content tunneled through an allowed server, and some shared/collapsed browser connections can evade page-level distinctions. A determined user with alternate accounts, another OS, admin credentials, a privileged network relay, a VM with an independent network path or physical recovery/boot access can bypass controls. Strict firewall coverage depends on Windows attributing the connection to the child; verify with the direct-access test. The design does not attempt TLS interception or full application allowlisting. Avoid giving the child access to a usable unrestricted local proxy or an independent VM.

## Operations and recovery

Run the following inside the Ubuntu project folder:

```bash
docker compose ps
docker compose logs --tail=100 dashboard
docker compose restart dashboard
```

**Reset a forgotten parent password**. This signs out existing dashboard sessions. Device pairings keep working.

```bash
docker compose run --rm --no-deps dashboard python -m server.admin
```

**Back up** with a short server stop so SQLite, its journal, the CA, TLS keys and settings form a consistent snapshot. Store this private backup securely. The Windows service continues enforcing its cache.

```bash
docker compose stop dashboard
(umask 077; tar -czf "../familytime-backup-$(date +%Y%m%d-%H%M%S).tar.gz" .env data tls private household-ca.crt)
docker compose start dashboard
```

Restore the archive into a fresh copy of this release with the service stopped and the same LAN IP and file owner, then run `docker compose up -d --build`. The restored snapshot defines the available server history. See the Windows guide to replay locally retained daily totals if the backup predates accepted reports.

**Update** by backing up, then extracting the new project files over the installation directory. Preserve .env, household-ca.crt, private/, tls/ and data/. Run `docker compose up -d --build`, then `bash make-client.sh` to produce a fresh Windows bundle. Use the Windows updater described in the guide. Prefer the same server/agent release version. There are no automatic cloud updates.

**Renew the leaf certificate** before its one-year expiry:

```bash
bash renew-cert.sh
docker compose restart dashboard
```

If the IP changes, stop the dashboard, update FT_LAN_IP in .env, renew the leaf, run `docker compose up -d`, and update each agent’s protected config.json server URL as administrator while the service is stopped. The same household CA still authenticates the new address. To change the household time zone, edit FT_ZONE and recreate the dashboard; the new zone applies on the next sync. Historical dates retain their original labels. The CA expires after ten years. Replacing it also requires redistributing the new public certificate.

**If first setup is interrupted**, keep the generated CA and database. After fixing the cause, finish the remaining steps individually:

```bash
bash renew-cert.sh
bash make-client.sh
docker compose build
docker compose run --rm --no-deps dashboard python -m server.admin
docker compose up -d
```

These commands assume .env, data/, tls/, private/ca.key and household-ca.crt were created. If initial key creation failed and no PC has been enrolled, start again in a new extracted directory. For Windows restoration and removal see **docs/WINDOWS.md**.

## Tests and source layout

```bash
python3 -m venv .venv
. .venv/bin/activate
python -m pip install -r requirements.txt
python -m unittest discover -s tests -v
node --check server/static/app.js
```

Run the suite on Linux with Python 3.11+, OpenSSL, bash and system tzdata. Node is only used for the optional dashboard syntax check. The suite exercises real API handlers, TLS verification, outage/replay, transactions, account-gate ownership, DST and schedule boundaries, domain matching, proxy request handling and live tunnel revocation. Windows-only validation and the release test record are in **docs/WINDOWS.md** and **docs/VERIFICATION.md**.

| Directory | Contents |
|---|---|
| server/ | HTTPS API, SQLite store, admin password tool and browser dashboard |
| familytime/ | Shared rules, Windows bindings, filter, durable agent journal and worker |
| windows/ | Installer/updater, service host, policy setup, read-only installation checks and recovery |
| tests/ | Automated server, agent, filter and policy tests |
