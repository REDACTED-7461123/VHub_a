import getpass
import os
from server.store import Store

if __name__ == "__main__":
    p = getpass.getpass("Parent password (12 or more characters): ")
    if p != getpass.getpass("Confirm password: "):
        raise SystemExit("Passwords did not match.")
    Store(os.getenv("FT_DB","/data/family.db")).set_password(p)
    print("Parent password saved. Previous dashboard sessions have expired.")
