import asyncio
import base64
import json
import os
import re
import secrets
import ssl
import time
from collections import deque
from datetime import date, datetime, timedelta
from pathlib import Path
from zoneinfo import ZoneInfo, TZPATH

from aiohttp import web
from familytime import rules
from server.store import Store, digest, log

STATIC = Path(__file__).with_name("static")

def fail(status, message):
    return web.json_response({"error": message}, status=status)

@web.middleware
async def boundary(request, handler):
    try:
        if request.method == "POST":
            if request.content_type != "application/json" or request.headers.get("X-Family-Request") != "1":
                return fail(403,"Use the dashboard or an authenticated agent.")
            origin = request.headers.get("Origin")
            if origin and origin != f"{request.scheme}://{request.host}":
                return fail(403,"Wrong request origin.")
            request["body"] = await request.json()
            if not isinstance(request["body"], dict):
                raise ValueError("Expected a JSON object.")
        path = request.path
        if path.startswith("/api/parent/"):
            session = request.cookies.get("__Host-family","")
            with request.app["store"].db() as db:
                row = db.execute("SELECT 1 FROM sessions WHERE hash=? AND expires>?", (digest(session),time.time())).fetchone()
            if not row:
                return fail(401,"Sign in to manage this household.")
        result = await handler(request)
    except (ValueError, KeyError, TypeError, UnicodeError):
        return fail(400,"Invalid request. Check the entered values.")
    result.headers.update({"Cache-Control":"no-store","X-Content-Type-Options":"nosniff",
        "Referrer-Policy":"no-referrer","X-Frame-Options":"DENY",
        "Content-Security-Policy":"default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; connect-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'self'"})
    return result

async def login(r):
    # Local single-parent server. Bound concurrent scrypt calls and attempts across source addresses.
    now = time.monotonic()
    attempts = r.app["attempts"]
    while attempts and attempts[0] < now-60:
        attempts.popleft()
    if len(attempts) >= 10:
        return fail(429,"Too many attempts. Try again in a minute.")
    attempts.append(now)
    password = r["body"].get("password")
    if not isinstance(password,str) or len(password) > 256:
        return fail(400,"Invalid password.")
    async with r.app["login_lock"]:
        token = await asyncio.to_thread(r.app["store"].login,password)
    if not token:
        return fail(401,"Incorrect password.")
    response = web.json_response({"ok":True})
    response.set_cookie("__Host-family",token,secure=True,httponly=True,samesite="Strict",path="/",max_age=43200)
    return response

async def logout(r):
    with r.app["store"].db() as db:
        db.execute("DELETE FROM sessions WHERE hash=?", (digest(r.cookies["__Host-family"]),))
    resp = web.json_response({"ok":True})
    resp.set_cookie("__Host-family","",path="/",max_age=0,secure=True,httponly=True,samesite="Strict")
    return resp

async def devices(r):
    with r.app["store"].db() as db:
        if r.method == "GET":
            rows = db.execute("SELECT id,name,secret IS NOT NULL AS paired FROM devices ORDER BY rowid")
            return web.json_response({"devices":[dict(x) for x in rows],"zone":r.app["zone"].key})
        name = r["body"].get("name")
        if not isinstance(name,str) or not 1 <= len(name.strip()) <= 60:
            return fail(400,"Use a device name of 1–60 characters.")
        key, code = r.app["store"].pair_code(db,name.strip())
        return web.json_response({"id":key,"code":code})

def bundle(r, row):
    return {"id":row["id"],"policy":json.loads(row["policy"]),"zone":r.app["zone"].key,
            "tzfile":r.app["tzfile"]}

async def pair(r):
    code, token = r["body"].get("code"),r["body"].get("token")
    if not isinstance(code,str) or not isinstance(token,str) or not re.fullmatch(r"[A-Za-z0-9_-]{43}",token):
        return fail(400,"Invalid pairing request.")
    with r.app["store"].db() as db:
        db.execute("BEGIN IMMEDIATE")
        row = db.execute("SELECT * FROM devices WHERE pair=? AND expiry>?",(digest(code),time.time())).fetchone()
        if not row or (row["secret"] and row["secret"] != digest(token)):
            return fail(403,"Pairing code is invalid, expired, or already used.")
        if not row["secret"]:
            if db.execute("SELECT 1 FROM devices WHERE secret=?", (digest(token),)).fetchone():
                return fail(409,"This credential already belongs to another device.")
            db.execute("UPDATE devices SET secret=? WHERE id=?",(digest(token),row["id"]))
            log(db,row["id"],"Windows agent paired")
        return web.json_response(bundle(r,row))

async def sync(r):
    auth = r.headers.get("Authorization","")
    if not auth.startswith("Bearer "):
        return fail(401,"Agent authentication required.")
    b = r["body"]
    with r.app["store"].db() as db:
        db.execute("BEGIN IMMEDIATE")
        row = db.execute("SELECT * FROM devices WHERE secret=?",(digest(auth[7:]),)).fetchone()
        if not row:
            return fail(401,"Unknown agent.")
        counts, status = b.get("usage"),b.get("status")
        if not isinstance(counts,dict) or len(counts)>128 or status not in rules.STATES:
            return fail(400,"Invalid agent report.")
        today = datetime.now(r.app["zone"]).date()
        parsed = []
        for key,value in counts.items():
            d = date.fromisoformat(key)
            if d.isoformat()!=key or d > today + timedelta(days=1):
                return fail(400,"Invalid usage date. Check the agent clock.")
            parsed.append((row["id"],key,rules.integer(value,0,90000)))
        rev = rules.integer(b["revision"], 0, 2**53)
        db.executemany("INSERT INTO usage VALUES(?,?,?) ON CONFLICT(device,day) DO UPDATE SET seconds=max(usage.seconds,excluded.seconds)",parsed)
        db.execute("UPDATE devices SET last_seen=?,status=?,applied=? WHERE id=?",(int(time.time()),status,rev,row["id"]))
        if status != row["status"] and status in ("restricted","error"):
            log(db,row["id"],"Time restriction in effect" if status=="restricted" else "Agent needs attention")
        return web.json_response(bundle(r,row))

async def detail(r):
    key = r.match_info["key"]
    with r.app["store"].db() as db:
        db.execute("BEGIN IMMEDIATE" if r.method=="POST" else "BEGIN")
        row = db.execute("SELECT * FROM devices WHERE id=?", (key,)).fetchone()
        if not row:
            return fail(404,"Device no longer exists.")
        p = json.loads(row["policy"])
        local = datetime.now(r.app["zone"])
        today = local.date()
        if r.method=="POST":
            b = r["body"]
            if b.get("revision") != p["revision"]:
                return fail(409,"Settings changed. Reload this device before saving.")
            action = b.get("action")
            try:
                if action == "schedule":
                    p["days"] = rules.days(b["days"])
                    msg = "Weekly schedule updated"
                elif action == "web":
                    p.update(rules.web(b))
                    msg = f"Website {p['mode']} saved"
                elif action == "adjust":
                    minutes = rules.integer(b["minutes"],-1440,1440)
                    k = today.isoformat()
                    base = p["days"][today.weekday()]["limit"]
                    total = max(0,min(1440,base+p["adjust"].get(k,0)+minutes))
                    p["adjust"][k] = total-base
                    msg = f"Time adjustment {minutes:+d} min · daily budget {total} min"
                elif action == "exception":
                    host = rules.domain(b["domain"])
                    duration = rules.integer(b["minutes"],1,10080)
                    p["exceptions"] = [e for e in p["exceptions"] if e["domain"] != host and e["until"]>time.time()]
                    if len(p["exceptions"])>=100:
                        return fail(400,"Remove an exception first.")
                    p["exceptions"].append({"domain":host,"until":int(time.time())+duration*60})
                    msg = f"Allowed {host} for {duration} min"
                elif action == "revoke":
                    host = rules.domain(b["domain"])
                    p["exceptions"] = [e for e in p["exceptions"] if e["domain"]!=host]
                    msg = f"Removed exception for {host}"
                elif action == "remove":
                    db.execute("DELETE FROM devices WHERE id=?",(key,))
                    return web.json_response({"ok": True})
                elif action == "recode" and row["secret"] is None:
                    code=secrets.token_urlsafe(18)
                    db.execute("UPDATE devices SET pair=?,expiry=? WHERE id=?",(digest(code),int(time.time())+900,key))
                    return web.json_response({"code":code})
                else:
                    return fail(400,"Unknown action.")
            except ValueError as e:
                return fail(400,str(e))
            p["adjust"] = {k:v for k,v in p["adjust"].items() if k>=today.isoformat()}
            p["revision"] += 1
            db.execute("UPDATE devices SET policy=? WHERE id=?",(json.dumps(p),key))
            log(db,key,msg)
            return web.json_response({"ok":True})
        count = rules.integer(int(r.query.get("days","30")),7,366)
        first = today-timedelta(days=count-1)
        raw = dict(db.execute("SELECT day,seconds FROM usage WHERE device=? AND day BETWEEN ? AND ?",(key,first.isoformat(),today.isoformat())))
        history = []
        for n in range(count):
            k=(first+timedelta(days=n)).isoformat()
            history.append({"day":k,"seconds":raw.get(k,0),"reported":k in raw})
        quota=rules.allowance(p,local,raw.get(today.isoformat(),0))
        return web.json_response({"id":key,"name":row["name"],"paired":bool(row["secret"]),
           "status":row["status"],"last_seen":row["last_seen"],"online":bool(row["last_seen"] and time.time()-row["last_seen"]<50),
           "applied":row["applied"],"policy":p,"zone":r.app["zone"].key,"today":today.isoformat(),
           "history":history,"week":sum(x["seconds"] for x in history[-1-today.weekday():]),"allowance":quota,
           "actions":[dict(x) for x in db.execute("SELECT at,detail FROM actions WHERE device=? ORDER BY id DESC LIMIT 40",(key,))]})

async def asset(r):
    name=r.match_info.get("name","index.html")
    if name not in {"index.html","app.js","app.css","icon.svg"}:
        raise web.HTTPNotFound()
    return web.FileResponse(STATIC/name)

def create_app(dbpath, zone):
    app=web.Application(middlewares=[boundary],client_max_size=128*1024)
    app["zone"]=ZoneInfo(zone)
    tz=next((Path(root)/zone for root in TZPATH if (Path(root)/zone).is_file()),None)
    if not tz:
        raise RuntimeError("Install system tzdata.")
    app["tzfile"]=base64.b64encode(tz.read_bytes()).decode()
    app["store"]=Store(dbpath)
    app["attempts"]=deque()
    app["login_lock"]=asyncio.Lock()
    app.router.add_get("/",asset)
    app.router.add_get("/assets/{name}",asset)
    app.router.add_post("/api/login",login)
    app.router.add_post("/api/parent/logout",logout)
    for method in ("GET","POST"):
        app.router.add_route(method,"/api/parent/devices",devices)
        app.router.add_route(method,"/api/parent/devices/{key}",detail)
    app.router.add_post("/api/agent/pair",pair)
    app.router.add_post("/api/agent/sync",sync)
    return app

if __name__=="__main__":
    tls=ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
    tls.minimum_version=ssl.TLSVersion.TLSv1_2
    tls.load_cert_chain("/tls/server.crt","/tls/server.key")
    web.run_app(create_app(os.getenv("FT_DB","/data/family.db"),os.getenv("FT_ZONE","UTC")),
                host="0.0.0.0",port=8443,ssl_context=tls,access_log=None)
