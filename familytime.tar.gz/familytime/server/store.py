import hashlib
import hmac
import json
import secrets
import sqlite3
import time
from contextlib import contextmanager
from pathlib import Path
from familytime.rules import defaults

def digest(token):
    return hashlib.sha256(token.encode()).hexdigest()

def password_hash(password, salt):
    return hashlib.scrypt(password.encode(), salt=salt, n=32768, r=8, p=1, maxmem=64*1024*1024).hex()

class Store:
    def __init__(self, path):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        with self.db() as db:
            db.executescript("""
            PRAGMA journal_mode=WAL;
            CREATE TABLE IF NOT EXISTS admin(id INTEGER PRIMARY KEY CHECK(id=1),salt TEXT,hash TEXT);
            CREATE TABLE IF NOT EXISTS sessions(hash TEXT PRIMARY KEY,expires INTEGER);
            CREATE TABLE IF NOT EXISTS devices(id TEXT PRIMARY KEY,name TEXT NOT NULL,secret TEXT,pair TEXT,expiry INTEGER,
              policy TEXT NOT NULL,last_seen INTEGER,status TEXT,applied INTEGER DEFAULT 0);
            CREATE UNIQUE INDEX IF NOT EXISTS device_secret ON devices(secret) WHERE secret IS NOT NULL;
            CREATE UNIQUE INDEX IF NOT EXISTS device_pair ON devices(pair) WHERE pair IS NOT NULL;
            CREATE TABLE IF NOT EXISTS usage(device TEXT REFERENCES devices ON DELETE CASCADE, day TEXT, seconds INTEGER,
              PRIMARY KEY(device,day));
            CREATE TABLE IF NOT EXISTS actions(id INTEGER PRIMARY KEY,device TEXT REFERENCES devices ON DELETE CASCADE,at INTEGER,detail TEXT);
            """)
    @contextmanager
    def db(self):
        db = sqlite3.connect(self.path, timeout=10)
        db.row_factory = sqlite3.Row
        try:
            db.execute("PRAGMA foreign_keys=ON")
            with db:
                yield db
        finally:
            db.close()
    def set_password(self, password):
        if not 12 <= len(password) <= 256:
            raise ValueError("Use a password of 12–256 characters.")
        salt = secrets.token_bytes(16)
        with self.db() as db:
            db.execute("REPLACE INTO admin VALUES (1,?,?)",(salt.hex(),password_hash(password,salt)))
            db.execute("DELETE FROM sessions")
    def login(self, password):
        with self.db() as db:
            row = db.execute("SELECT * FROM admin WHERE id=1").fetchone()
            if not row or not hmac.compare_digest(row["hash"],password_hash(password,bytes.fromhex(row["salt"]))):
                return None
            # A concurrent password reset must invalidate an in-flight login too.
            db.execute("BEGIN IMMEDIATE")
            current = db.execute("SELECT hash FROM admin WHERE id=1").fetchone()
            if not current or not hmac.compare_digest(current["hash"], row["hash"]):
                return None
            token = secrets.token_urlsafe(32)
            db.execute("DELETE FROM sessions WHERE expires<=?", (time.time(),))
            db.execute("INSERT INTO sessions VALUES (?,?)",(digest(token),int(time.time())+43200))
            return token
    def pair_code(self, db, name):
        key, code = secrets.token_hex(8), secrets.token_urlsafe(18)
        db.execute("INSERT INTO devices(id,name,pair,expiry,policy,status) VALUES(?,?,?,?,?,?)",
                   (key,name,digest(code),int(time.time())+900,json.dumps(defaults()),"away"))
        log(db,key,"Device added")
        return key, code

def log(db,key,detail):
    db.execute("INSERT INTO actions(device,at,detail) VALUES(?,?,?)",(key,int(time.time()), detail))
