(function dashboard() {
"use strict";
const $=s=>document.querySelector(s);
const esc=s=>String(s).replace(/[<>&"']/g,c=>({"<":"&lt;",">":"&gt;","&":"&amp;",'"':"&quot;","'":"&#39;"}[c]));
const pages=["Overview","Time limits","Website rules","History"];
const icons=['<rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/>','<circle cx="12" cy="12" r="9"/><path d="M12 6v6l4 2"/>','<circle cx="12" cy="12" r="9"/><ellipse cx="12" cy="12" rx="4" ry="9"/><path d="M3 12h18"/>','<path d="M3 11a9 9 0 1 1 2 7M3 4v7h7m2-4v6l3 2"/>'];
const weekdays=["Monday","Tuesday","Wednesday","Thursday","Friday","Saturday","Sunday"];
let page=0,device="",list=[],data=null,chartDays=7,historyDays=30,serial=0,busy=false,dialogAction=null;
const fmt=s=>{const m=Math.floor(s/60);return m>=60?`${Math.floor(m/60)}h ${m%60}m`:m?`${m}m`:s?`${Math.floor(s)}s`:"0m"};
const stamp=s=>new Intl.DateTimeFormat(undefined,{timeZone:data.zone,month:"short",day:"numeric",hour:"2-digit",minute:"2-digit"}).format(s*1000);
const clock=n=>`${String(Math.floor(n/60)).padStart(2,"0")}:${String(n%60).padStart(2,"0")}`;
const dayName=(day,style)=>new Date(day+"T12:00:00Z").toLocaleDateString(undefined,{timeZone:"UTC",...style});
const note=s=>{$("#notice").textContent=s};
function signedOut(){serial++;device="";data=null;$("#shell").hidden=true;$("#login").hidden=false;$("#password").focus();if($("#dialog").open)$("#dialog").close()}
async function api(path,body){
 const opts=body===undefined?{}:{method:"POST",headers:{"Content-Type":"application/json","X-Family-Request":"1"},body:JSON.stringify(body)};
 const r=await fetch(path,opts);
 const j=await r.json();
 if(!r.ok){if(r.status===401&&!path.endsWith("/login"))signedOut();throw Error(j.error||"Request failed")}
 return j;
}
function showModal(title,body,button,action){
 $("#dialogtitle").textContent=title;$("#dialogbody").innerHTML=body;$("#confirm").hidden=!button;
 $("#confirm").textContent=button||"";dialogAction=action;
 if(!$("#dialog").open)$("#dialog").showModal();
}
function showCode(code){
 showModal("Windows pairing code",`<p>Enter this code in the Windows installer within 15 minutes.</p><input class="code" readonly aria-label="Pairing code" value="${esc(code)}">`,null,null);
}
function pair(){showModal("Pair a device",'<label class="field">Device name<input name="name" required maxlength="60" autocomplete="off" autofocus></label>',"Create code",async form=>{
 const r=await api("/api/parent/devices",{name:form.get("name")});device=r.id;await loadDevices();showCode(r.code);
})}
async function loadDevices(){
 const r=await api("/api/parent/devices");list=r.devices;
 if(!list.some(d=>d.id===device))device=list[0]?.id||"";
 $("#device").innerHTML=list.length?list.map(d=>`<option value="${esc(d.id)}">${esc(d.name)}</option>`).join(""):'<option>No paired devices</option>';
 $("#device").value=device;
 $("#login").hidden=true;$("#shell").hidden=false;
 await load();
}
async function load(quiet=false){
 const n=++serial;
 if(!device){data=null;render();return}
 const r=await api(`/api/parent/devices/${device}?days=${Math.max(chartDays,historyDays)}`);
 if(n!==serial)return;
 if(quiet&&page!==0&&page!==3&&data){connection(r);return}
 data=r;render();
}
function connection(d){
 const el=$("#connection");el.hidden=!d;if(!d)return;
 el.classList.toggle("online",d.online&&d.status!=="error");
 let state=!d.paired?"Awaiting pairing":!d.online?"Offline":{active:"In use",idle:"Idle",away:"Signed out or disconnected",locked:"Locked",restricted:"Time restricted",error:"Agent error"}[d.status];
 el.textContent=state;
 el.title=d.last_seen?`Last report ${stamp(d.last_seen)}`:"No reports yet";
}
function chart(rows){
 const w=600,h=177,left=37,base=143,width=(w-left-5)/rows.length;
 const max=Math.max(3600,Math.ceil(Math.max(...rows.map(x=>x.seconds))/3600)*3600);
 let svg=`<svg class="chart" viewBox="0 0 ${w} ${h}" role="img" aria-label="Daily active screen time in hours. Exact totals are in History.">`;
 for(let i=0;i<=2;i++){let y=base-(base-12)*i/2;svg+=`<line class="line" x1="${left}" y1="${y}" x2="${w}" y2="${y}"/><text x="0" y="${y+4}">${max/3600*i/2}h</text>`}
 rows.forEach((r,i)=>{const x=left+i*width+width*.22,b=Math.max(2,(base-12)*r.seconds/max);
  svg+=`<rect class="${r.seconds?(i===rows.length-1?"last":"bar"):"zero"}" x="${x}" y="${base-b}" width="${width*.56}" height="${b}" rx="2"><title>${r.day}: ${r.reported?fmt(r.seconds):"No report"}</title></rect>`;
  if(rows.length<=7||i%5===0||i===rows.length-1)svg+=`<text x="${left+(i+.5)*width}" y="166" text-anchor="middle">${dayName(r.day,rows.length<=7?{weekday:"short"}:{day:"numeric"})}</text>`;
 });
 return svg+"</svg>";
}
function recent(limit){
 const a=data.actions.slice(0,limit);
 return `<section class="card"><div class="cardhead"><h2>Recent actions</h2></div><ul class="events">${a.map(x=>`<li class="row"><span>${esc(x.detail)}</span><time class="muted">${esc(stamp(x.at))}</time></li>`).join("")||"<li>No actions yet.</li>"}</ul></section>`;
}
function overview(){
 const d=data,p=d.policy,a=d.allowance,last=d.history.at(-1);
 const index=(new Date(d.today+"T12:00Z").getUTCDay()+6)%7,rule=p.days[index];
 const stale=!d.online?"Last reported totals":a.reason||"Available before the next cutoff";
 return `<section class="cards stats"><div class="metric hero"><label>Available now</label><div class="number">${fmt(a.available)}</div><span class="muted">${esc(stale)}</span></div><div class="metric"><label>Used today</label><div class="number">${fmt(last.seconds)}</div><span class="muted">of ${fmt(a.quota)} daily budget</span></div><div class="metric"><label>This week</label><div class="number">${fmt(d.week)}</div><span class="muted">Monday through today</span></div></section>
 <div class="grid"><section class="card"><div class="cardhead"><h2>Screen time</h2><select id="range" aria-label="Chart period"><option value="7">Last 7 days</option><option value="30" ${chartDays===30?"selected":""}>Last 30 days</option></select></div>${chart(d.history.slice(-chartDays))}</section>
 <section class="card"><h2>Today’s controls</h2><div class="row"><span>Allowed hours</span><strong>${clock(rule.start)}–${clock(rule.end)}</strong></div><div class="row"><span>Unused budget</span><strong>${fmt(a.remaining)}</strong></div><div class="buttons"><button class="primary" data-min="30">＋30 min</button><button class="secondary" data-min="-15">−15 min</button><button class="secondary" id="custom">Custom</button></div></section></div>${recent(4)}`;
}
function schedule(){
 const rows=data.policy.days.map((r,i)=>`<div class="weekrow"><strong>${weekdays[i].slice(0,3)}</strong><input name="l${i}" aria-label="${weekdays[i]} daily minutes" type="number" min="0" max="1440" value="${r.limit}" required><input name="s${i}" aria-label="${weekdays[i]} starts" value="${clock(r.start)}" required pattern="[0-2][0-9]:[0-5][0-9]"><input name="e${i}" aria-label="${weekdays[i]} ends" value="${clock(r.end)}" required pattern="[0-2][0-9]:[0-5][0-9]"></div>`).join("");
 return `<section class="card"><h2>Weekly schedule</h2><p class="muted sub">Hours use ${esc(data.zone)}. Use 24:00 for midnight, or set the daily limit to zero for a day off.</p><form id="schedule"><div class="weekrow head"><span>Day</span><span>Daily minutes</span><span>From</span><span>Until</span></div>${rows}<div class="buttons"><button class="primary">Save schedule</button></div></form></section>`;
}
function websites(){
 const p=data.policy;
 return `<section class="card"><form id="web" class="formgrid"><h2>Website filter</h2><label class="field">Mode<select name="mode"><option value="blocklist">Block listed websites</option><option value="allowlist" ${p.mode==="allowlist"?"selected":""}>Allow only listed websites</option></select></label><label class="field">Domains<textarea name="domains" rows="6" spellcheck="false">${esc(p.domains.join("\n"))}</textarea></label><p class="muted">One domain per line. Each entry also covers its subdomains.</p><div><button class="primary">Save website rules</button></div></form></section>
 <section class="card"><h2>Temporary access</h2><p class="muted sub">Allow a website until its exception expires.</p><form id="exception" class="inline"><label class="field">Domain<input name="domain" required></label><label class="field">Minutes<input type="number" min="1" max="10080" name="minutes" value="30" required></label><button class="secondary">Allow temporarily</button></form><div class="space">${p.exceptions.filter(x=>x.until>Date.now()/1000).map(e=>`<div class="row"><span><strong>${esc(e.domain)}</strong><br><small>Until ${esc(stamp(e.until))}</small></span><button class="secondary" data-revoke="${esc(e.domain)}">Revoke</button></div>`).join("")}</div></section>`;
}
function history(){
 return `${recent(40)}<section class="card"><div class="cardhead"><h2>Daily usage</h2><select id="historyrange" aria-label="History period">${[7,30,90,366].map(n=>`<option value="${n}" ${n===historyDays?"selected":""}>Last ${n} days</option>`).join("")}</select></div><table><thead><tr><th>Date</th><th>Active time</th></tr></thead><tbody>${data.history.slice(-historyDays).reverse().map(d=>`<tr><td>${esc(d.day)}</td><td>${d.reported?fmt(d.seconds):"No report"}</td></tr>`).join("")}</tbody></table></section><section class="card"><h2>Device management</h2><p class="muted">Uninstall the Windows agent first to restore local access. Removing this device clears its server history.</p><div class="buttons"><button class="danger" id="remove">Remove device</button></div></section>`;
}
function render(){
 $("#title").textContent=pages[page];connection(data);
 $("#date").textContent=data?`${data.name} · ${dayName(data.today,{weekday:"long",month:"short",day:"numeric"})}`:"Household";
 $("nav").innerHTML=pages.map((p,i)=>`<button data-page="${i}" ${i===page?'aria-current="page"':""}><svg class="icon" viewBox="0 0 24 24" aria-hidden="true">${icons[i]}</svg>${p}</button>`).join("");
 if(!data){$("#view").innerHTML='<section class="card empty"><h2>Connect your first PC</h2><p class="muted">Create a pairing code for the Windows installer.</p><div class="buttons"><button class="primary" id="first">Pair a device</button></div></section>';return}
 const waiting=data.paired?"":'<section class="card"><h2>Waiting for the Windows installer</h2><p class="muted">You can set rules before pairing. A fresh code replaces the previous one.</p><div class="buttons"><button class="secondary" id="recode">Generate new pairing code</button></div></section>';
 const pending=data.paired&&data.applied<data.policy.revision?'<p class="muted">Settings saved · waiting for the agent to confirm.</p>':"";
 $("#view").innerHTML=waiting+pending+[overview,schedule,websites,history][page]();
}
async function save(action,extra={},msg="Saved."){
 const id=device,rev=data.policy.revision;
 const result=await api(`/api/parent/devices/${id}`,{action,revision:rev,...extra});
 if(id===device){if(action==="remove")await loadDevices();else await load();note(msg)}
 return result;
}
async function work(fn){
 if(busy)return;busy=true;
 try{await fn()}catch(e){note(e.message);if($("#dialog").open){let el=$("#dialogerror");if(!el){el=document.createElement("p");el.id="dialogerror";el.setAttribute("role","alert");$("#dialogbody").append(el)}el.textContent=e.message}}
 finally{busy=false}
}
$("#loginform").onsubmit=async e=>{e.preventDefault();try{await api("/api/login",{password:$("#password").value});$("#password").value="";$("#loginerror").textContent="";note("");await loadDevices()}catch(x){$("#loginerror").textContent=x.message}};
$("#logout").onclick=()=>work(async()=>{await api("/api/parent/logout",{});signedOut()});
$("#pair").onclick=pair;$("#cancel").onclick=()=>$("#dialog").close();
$("#dialogform").onsubmit=e=>{e.preventDefault();const fn=dialogAction;if(fn)work(()=>fn(new FormData(e.target)))};
$("#device").onchange=e=>work(async()=>{device=e.target.value;data=null;note("");await load()});
document.addEventListener("click",e=>{
 const t=e.target.closest("button");if(!t||busy)return;
 if(t.dataset.page!==undefined){page=Number(t.dataset.page);note("");work(()=>load());return}
 if(t.id==="first")pair();
 if(t.dataset.min)work(()=>save("adjust",{minutes:+t.dataset.min},"Today’s budget updated."));
 if(t.id==="custom")showModal("Adjust today’s budget",'<label class="field">Minutes to add or subtract<input name="minutes" type="number" min="-1440" max="1440" value="15" required></label>',"Apply adjustment",async f=>{await save("adjust",{minutes:+f.get("minutes")});$("#dialog").close()});
 if(t.dataset.revoke)work(()=>save("revoke",{domain:t.dataset.revoke}));
 if(t.id==="recode")work(async()=>showCode((await save("recode",{},"New code created.")).code));
 if(t.id==="remove")showModal("Remove this device?",'<p>This permanently deletes its usage history and pairing. The Windows agent keeps enforcing its cached policy until uninstalled.</p>',"Remove device",async()=>{await save("remove",{},"Device removed.");$("#dialog").close()});
});
$("#view").onchange=e=>{
 if(e.target.id==="range"){chartDays=+e.target.value;work(()=>load())}
 if(e.target.id==="historyrange"){historyDays=+e.target.value;work(()=>load())}
};
$("#view").onsubmit=e=>{
 e.preventDefault();const f=new FormData(e.target);
 const minutes=k=>{const [h,m]=f.get(k).split(":").map(Number);return h*60+m};
 if(e.target.id==="schedule")work(()=>save("schedule",{days:weekdays.map((_,i)=>({limit:+f.get("l"+i),start:minutes("s"+i),end:minutes("e"+i)}))}));
 if(e.target.id==="web")work(()=>save("web",{mode:f.get("mode"),domains:f.get("domains").split(/\r?\n/).map(s=>s.trim()).filter(Boolean)}));
 if(e.target.id==="exception")work(()=>save("exception",{domain:f.get("domain"),minutes:+f.get("minutes")}));
};
loadDevices().catch(e=>{if($("#login").hidden){signedOut();$("#loginerror").textContent=e.message}});
setInterval(()=>{if(!busy&&!document.hidden&&!$("#shell").hidden&&!$("#dialog").open&&device)load(true).catch(e=>note(e.message))},15000);
})();
