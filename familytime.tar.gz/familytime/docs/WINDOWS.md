# Windows installation and acceptance checks

## Install

Use a 64-bit Windows 10/11 PC with Windows PowerShell 5.1, Windows Defender Firewall enabled in all profiles, and an enabled **local standard** child account. Keep a separate parent administrator account with a known password. Install 64-bit CPython 3.11+ for **all users** into its normal Program Files directory. An official full Python installer for Windows, such as the 3.13 x64 installer, can be brought in on USB. No pip packages are needed on the child PC.

From the Ubuntu project, run `bash make-client.sh` if the Windows bundle is missing. Transfer only windows-client.zip to the parent’s private profile. Extract everything. Right-click **windows/Install.cmd → Run as administrator** using the parent account. Keep the extracted code in a directory the child cannot modify. Before installing on a shared computer, close open browsers and save the child’s work.

The installer takes the HTTPS address, the local username and the dashboard’s one-time pairing code. It checks the account and policy conflicts, compiles the service host locally, installs to the protected Familytime folder in Program Files, installs the firewall/browser policies and checks worker readiness. If installed in strict mode, the child can access permitted public and LAN websites through the local proxy. Direct connections by the managed child to the internet or LAN will be blocked. Browser proxy settings also apply to other users of this Windows PC.

If other network applications must continue to connect directly, use this command **instead of** Install.cmd in an elevated 64-bit Windows PowerShell from the extracted bundle root:

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\windows\Install.ps1 -BrowserOnly
```

This mode applies the same browser policies and time restrictions, but a portable unmanaged browser, raw socket, VPN, or other network application can bypass the web filter. Switching modes requires uninstalling and reinstalling. The process-scoped execution policy option lets local installer scripts run. It does not modify system execution policy.

On a failed pairing, check the PC clock, Ubuntu address, trusted CA file in the bundle and the code’s 15-minute lifetime. A failed installation after successful pairing can leave a paired server record. Remove that record in History and generate a new pairing before retrying. Avoid reusing an old bundle from another household.

## Verify on the actual PC

Use a throwaway local standard account and save open work before testing short budgets. The installer should refuse an admin or Microsoft account. Do one complete pass before deploying to the child.

1. **Service and permissions.** From an elevated parent PowerShell, inside the extracted bundle, run the following read-only checks.

   ```powershell
   powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\windows\Check.ps1
   Get-Service Familytime
   ```

   Reboot and repeat. From the *standard child account*, `Stop-Service Familytime` and listing `"$env:ProgramFiles\Familytime\state"` should produce access-denied errors. Do not grant the child administrator access or adjust the folder/service permissions.

2. **Browser policy.** After a full quit and relaunch, inspect chrome://policy and edge://policy for ProxySettings and QuicAllowed; inspect about:policies in Firefox for a locked manual Proxy. In every browser open example.org, block example.org from the dashboard and try a fresh private window. It should fail after the next sync; another public domain should still load. Check the domain and a real subdomain. Observe the pending indicator clear on Overview.

3. **Allowlist and expiry.** Configure allowlist mode with example.org only. Verify example.org loads and example.com fails. Add a one-minute exception for example.com, sync, and confirm access. Stop the Ubuntu dashboard after the rule arrives; wait for expiry and try a new request. It should fail without server contact. Switch the dashboard back on. A cached page can still be visible; use a fresh navigation or uncached resource.

4. **Direct bypass.** In the **child’s** PowerShell in strict mode, these first two commands should fail and the third should reach the permitted site. In the browser-only mode the direct test may succeed. Test IPv6 as well if the LAN has working IPv6. Verify another working network application under the parent account can connect directly.

   ```powershell
   curl.exe --noproxy "*" --connect-timeout 5 https://example.org/
   curl.exe --noproxy "*" --connect-timeout 5 https://1.1.1.1/
   curl.exe --proxy http://127.0.0.1:17841 --connect-timeout 8 https://example.org/
   ```

5. **Time accounting.** Use the child account for three minutes, lock with Win+L for three, then resume. Repeat with sleep, fast-user switching and a signed-out child. Compare History after synchronization. The active portion should be charged once, with small sampling differences; check locked and sleep time contributed no material usage. Leave an unlocked session idle for more than five minutes and check the dashboard reports Idle. Input simulation and passive media can affect idle estimates.

6. **Cutoffs.** Give the child six unused minutes, keep using the PC, and check five-minute and one-minute warnings. At zero, verify disconnect or sign-out, and try signing back in. Check the separate parent account remains usable. Add 15 minutes and verify child sign-in resumes. Repeat with a schedule ending shortly. Extra minutes must not override the schedule end. Test a zero-budget day, the midnight boundary and subtracting time below already-used time.

7. **Offline and reconnection.** Let the PC receive a short policy, then stop the Ubuntu container. Reboot the PC, use it up to the cutoff, and verify account and website restrictions. Restart Ubuntu. The same daily total should appear without duplication. Change a rule on the server while the agent is unreachable; check it applies once both are connected.

8. **Update and recovery.** Back up server data, run the updater, and verify the same device and totals remain. Test the uninstall on the throwaway device, including while its child account is time-restricted. Verify the account, browsers and firewall return to normal before using the real child account.

## Update

Use a fresh windows-client.zip produced by the updated Ubuntu project. In an elevated PowerShell started in the newly extracted bundle root:

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\windows\Install.ps1 -Update
```

The updater stages and compiles new files before stopping the service. It keeps the pairing, usage journal and policy, and attempts a code rollback if startup fails. Keep the system-wide Python installation available at its original path. If upgrading Python into a new Program Files directory, update the administrator-protected python.path file to its full python.exe path while the service is stopped, then restart and rerun Check.ps1.

## Uninstall, inspect or restore access

From the parent administrator account in an **elevated** PowerShell:

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "$env:ProgramFiles\Familytime\Uninstall.ps1"
```

This stops and removes the service, re-enables an account disabled by Familytime, removes its firewall and browser policies, and deletes the local usage cache and token. Close and reopen all browsers. Afterwards remove the device in the dashboard if you want to erase its server records.

If the worker fails, inspect its bounded diagnostic log:

```powershell
Get-Content "$env:ProgramFiles\Familytime\state\service.log" -Tail 40
```

For emergency recovery when the normal uninstaller cannot run, sign in as the separate parent administrator and use an elevated PowerShell. The following reads the exact configured SID, stops enforcement and prompts you to verify the account before enabling it. This intentionally overrides the current time policy.

```powershell
$root = Join-Path $env:ProgramFiles 'Familytime'
$config = Get-Content "$root\config.json" -Raw | ConvertFrom-Json
Get-LocalUser -SID $config.sid | Format-Table Name,SID,Enabled
Set-Service Familytime -StartupType Disabled
Stop-Service Familytime -ErrorAction SilentlyContinue
Enable-LocalUser -SID $config.sid -Confirm
. "$root\Policy.ps1"
Remove-FamilyPolicy
```

Restart browsers. Repair/reinstall or uninstall the agent before relying on it again. While Familytime owns temporary account disabling, use its dashboard to manage cutoffs; simultaneous manual enable/disable operations have ambiguous ownership.

To replay locally retained totals after restoring an **older Ubuntu backup**, run the following as parent administrator on each still-paired PC. Keep the same device identity and database. The server merges cumulative totals idempotently.

```powershell
$root = Join-Path $env:ProgramFiles 'Familytime'
$python = (Get-Content "$root\python.path" -Raw).Trim()
Stop-Service Familytime
try { & $python -I -B "$root\runner.py" replay } finally { Start-Service Familytime }
```

If the backup predates that PC’s pairing, the token in the restored database cannot authenticate it. Retire and re-pair the PC as a new device. Server deletion does not uninstall a disconnected client.

## Native references

- WTS session flags and last-input timestamp — https://learn.microsoft.com/en-us/windows/win32/api/wtsapi32/ns-wtsapi32-wtsinfoex_level1_w
- Sleep-excluding Windows interrupt time — https://learn.microsoft.com/en-us/windows/win32/api/realtimeapiset/nf-realtimeapiset-queryunbiasedinterrupttime
- Local account flags — https://learn.microsoft.com/en-us/windows/win32/api/lmaccess/nf-lmaccess-netusersetinfo
- Windows Firewall local-user rules — https://learn.microsoft.com/en-us/powershell/module/netsecurity/new-netfirewallrule
- Edge mandatory proxy settings — https://learn.microsoft.com/en-us/deployedge/microsoft-edge-policies/proxysettings
- Chrome enterprise proxy settings — https://chromeenterprise.google/policies/#ProxySettings
- Firefox locked proxy settings — https://mozilla.github.io/enterprise-admin-reference/reference/policies/proxy/
