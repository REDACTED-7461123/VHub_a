# Release verification

Version 1.0.0 was exercised on Linux using Python 3.12.14 and aiohttp 3.14.4.

| Check | Result |
|---|---|
| Automated suite | 23 tests passed. Run `python -m unittest discover -s tests -v` from the project root. |
| Real HTTPS integration | Generated a private test CA, issued a leaf with the supplied renewal script, paired the production agent transport with the production API on a local TLS socket, stopped the listener, recorded offline usage, restarted the listener and synchronized the retained total. A hostname mismatch was rejected. |
| Accounting and enforcement decisions | Simulated Windows session states exercised warnings, lock/sleep exclusion, budget exhaustion, persisted account gating, recovery, policy changes and proxy failure. Separate tests covered weekday changes, daily adjustments, midnight and DST. |
| Filtering | Real TCP proxy connections to a test upstream exercised allowed CONNECT traffic, live tunnel revocation, expired exceptions and denial. Other tests cover hostname boundaries, private LAN handling, loopback denial and ambiguous HTTP framing. |
| Dashboard/API | Login/logout, CSRF/origin checks, token separation, single-use enrollment, multiple devices, stale-edit conflict, usage retries, daily/weekly aggregation, exception management and deletion were exercised against the API. Dashboard JavaScript passed a syntax check. A simulated DOM smoke test rendered all four views, applied a time adjustment and opened pairing. |
| Packaging | Shell syntax and Python compilation checked. Parsed the Compose YAML and compiled its healthcheck command. Generated and inspected a Windows client ZIP from a temporary setup. The final source archive was extracted and the automated suite rerun. |

## Boundaries of this verification

A Windows VM, PowerShell runtime, Docker daemon and graphical browser were unavailable in the build environment. Windows installation and C# compilation, actual WTS/account behavior, browser enterprise policy adoption, live firewall traffic attribution, browser visual layout, and a real Docker image build/start remain unverified here. Local TLS and service logic were exercised outside Docker. Follow the Windows acceptance procedure before using the system for enforcement on the real PC.
