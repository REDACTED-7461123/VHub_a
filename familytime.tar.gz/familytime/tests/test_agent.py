import asyncio
import base64
import io
import json
import os
import secrets
import shutil
import ssl
import subprocess
import tempfile
import unittest
from datetime import datetime
from pathlib import Path
from unittest.mock import patch
from aiohttp import web
from familytime import agent,rules
from familytime.agentstore import Local
from server.app import create_app

class Desktop:
    is_disabled=False
    def flags(self,user):return 2 if self.is_disabled else 0
    def set_disabled(self,user,value):self.is_disabled=value

class Gate(unittest.TestCase):
    def test_offline_restart_account_restoration(self):
        with tempfile.TemporaryDirectory() as folder:
            p=Path(folder)/"state";win=Desktop();local=Local(p)
            with patch.object(agent,"win",win):
                agent.gate(local,"child",True);self.assertTrue(win.is_disabled)
                local.db.close();local=Local(p)
                agent.gate(local,"child",False);self.assertFalse(win.is_disabled)
                win.is_disabled=True
                agent.gate(local,"child",True);agent.gate(local,"child",False)
                self.assertTrue(win.is_disabled,"A pre-disabled account must stay disabled")
            local.db.close()

class TLS(unittest.IsolatedAsyncioTestCase):
    async def test_real_agent_transport_and_offline_reconciliation(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp)
            (root/"private").mkdir();(root/"tls").mkdir()
            (root/".env").write_text("FT_LAN_IP=127.0.0.1\n")
            subprocess.run(["openssl","req","-x509","-newkey","rsa:2048","-nodes","-days","1","-subj","/CN=Test household CA",
                "-addext","basicConstraints=critical,CA:TRUE","-keyout","private/ca.key","-out","household-ca.crt"],cwd=root,check=True,capture_output=True)
            shutil.copy(Path(__file__).resolve().parents[1]/"renew-cert.sh",root)
            subprocess.run(["bash","renew-cert.sh"],cwd=root,check=True,capture_output=True)
            ctx=ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
            ctx.load_cert_chain(root/"tls/server.crt",root/"tls/server.key")
            app=create_app(root/"server.db","Europe/Istanbul")
            runner=web.AppRunner(app);await runner.setup()
            site=web.TCPSite(runner,"127.0.0.1",0,ssl_context=ctx);await site.start()
            port=runner.addresses[0][1]
            with app["store"].db() as db:
                key,code=app["store"].pair_code(db,"Desk")
            config={"server":f"https://127.0.0.1:{port}"}
            token=secrets.token_urlsafe(32)
            async def rpc(path,b,secret=None):return await asyncio.to_thread(agent.rpc,config,path,b,secret)
            with patch.object(agent,"ROOT",root):
                try:
                    b=await rpc("/api/agent/pair",{"code":code,"token":token})
                    self.assertEqual(b["id"],key)
                    local=Local(root/"agent.db");local.put("token",token);local.put("bundle",b)
                    day=datetime.now(agent.timezone(b)).date().isoformat()
                    local.add(day,60)
                    await site.stop()
                    with self.assertRaises(OSError):
                        await rpc("/api/agent/sync",{"usage":local.pending(),"status":"active","revision":1},token)
                    local.add(day,20);local.db.close()
                    local=Local(root/"agent.db");self.assertEqual(local.pending()[day],80)
                    a=agent.Agent(local,config)
                    self.assertEqual(a.bundle["policy"]["days"],rules.defaults()["days"])
                    site=web.TCPSite(runner,"127.0.0.1",port,ssl_context=ctx);await site.start()
                    task=asyncio.create_task(a.sync())
                    try:
                        async with asyncio.timeout(5):
                            while local.pending():await asyncio.sleep(.02)
                    finally:
                        task.cancel()
                        await asyncio.gather(task,return_exceptions=True)
                    with app["store"].db() as db:
                        self.assertEqual(db.execute("SELECT seconds FROM usage WHERE device=?",(key,)).fetchone()[0],80)
                    config["server"]=f"https://localhost:{port}"
                    with self.assertRaises(OSError):await rpc("/api/agent/sync",{},token)
                    local.db.close()
                finally:await runner.cleanup()

class Sampling(unittest.TestCase):
    def test_warning_cutoff_offline_restart_sleep_and_unlock(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);local=Local(root/"db")
            p=rules.defaults()
            for d in p["days"]:d["limit"]=1
            local.put("bundle",{"id":"unit","zone":"UTC","policy":p,"tzfile":base64.b64encode(Path("/usr/share/zoneinfo/UTC").read_bytes()).decode()})
            win=Desktop();win.state="active";warnings=[];locks=[]
            win.username=lambda sid:"child"
            win.observe=lambda user:(win.state,[7])
            win.lock_sessions=lambda ids:locks.extend(ids)
            win.warn=lambda ids,left:warnings.append(left)
            start=1793613600
            with patch.object(agent,"win",win),patch.object(agent,"STATE",root):
                a=agent.Agent(local,{"sid":"managed"})
                for i in range(0,32,2):a.sample(start+i,100+i,True)
                day=datetime.fromtimestamp(start,a.zone).date().isoformat()
                self.assertEqual(local.used(day),30)
                win.state="locked";a.sample(start+32,132,True)
                win.state="active";a.sample(start+3632,134,True)
                self.assertEqual(local.used(day),30)
                for i in range(2,32,2):a.sample(start+3632+i,134+i,True)
                self.assertEqual(local.used(day),60);self.assertEqual(a.status,"restricted")
                self.assertTrue(win.is_disabled);self.assertEqual(locks,[7]);self.assertEqual(warnings,[60])
                local.db.close();local=Local(root/"db");a=agent.Agent(local,{"sid":"managed"})
                a.sample(start+3700,200,True);self.assertTrue(win.is_disabled)
                a.bundle["policy"]["adjust"][day]=15
                a.sample(start+3702,202,True);self.assertFalse(win.is_disabled)
                a.sample(start+3704,204,False);self.assertTrue(win.is_disabled);self.assertEqual(a.status,"error")
            local.db.close()
