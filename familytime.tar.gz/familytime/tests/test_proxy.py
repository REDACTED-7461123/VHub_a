import asyncio
import ipaddress
import time
import unittest
from familytime.proxy import WebFilter, parse_head, Denied, connect_host, routable_destination
from familytime.rules import defaults

class Parser(unittest.TestCase):
    def test_reject_ambiguous_or_unsupported(self):
        for raw in (b"CONNECT user:pw@good.net:443 HTTP/1.1",b"CONNECT foo.net:25 HTTP/1.1",
                    b"GET http://x.net HTTP/1.1\r\nContent-Length: 1\r\nContent-Length: 0",
                    b"GET http://x.net HTTP/1.1\r\nTransfer-Encoding: chunked",
                    b"CONNECT 127.0.0.1:443 HTTP/1.1"):
            with self.assertRaises((Denied,ValueError)):parse_head(raw+b"\r\n\r\n")
    def test_lan_websites_and_sensitive_destinations(self):
        for addr in ("10.0.0.9","192.168.1.12","fd00::25","8.8.8.8"):
            self.assertTrue(routable_destination(ipaddress.ip_address(addr)))
        for addr in ("127.0.0.1","::1","169.254.169.254","224.0.0.1","fe80::1","::ffff:127.0.0.1"):
            self.assertFalse(routable_destination(ipaddress.ip_address(addr)))
        self.assertEqual(parse_head(b"CONNECT study_platform.com:443 HTTP/1.1\r\n\r\n")[1],"study_platform.com")
    def test_rewrite_host(self):
        _,_,_,out=parse_head(b"GET http://ok.net/a?q=1 HTTP/1.1\r\nHost: bad.net\r\nProxy-Authorization: a\r\n\r\n")
        self.assertIn(b"Host: ok.net",out);self.assertNotIn(b"bad.net",out);self.assertNotIn(b"uthorization",out)

class Proxy(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.p=defaults()
        async def echo(reader,writer):
            try:
                while data:=await reader.read(65536):
                    writer.write(data);await writer.drain()
            finally:writer.close()
        self.echo=await asyncio.start_server(echo,"127.0.0.1",0)
        async def local(host,port):
            return await asyncio.open_connection("127.0.0.1",self.echo.sockets[0].getsockname()[1])
        self.f=WebFilter(lambda:self.p,local)
        self.server=await asyncio.start_server(self.f.handle,"127.0.0.1",0)
    async def asyncTearDown(self):
        for s in (self.server,self.echo):
            s.close();await s.wait_closed()
    async def open(self,host):
        r,w=await asyncio.open_connection("127.0.0.1",self.server.sockets[0].getsockname()[1])
        w.write(f"CONNECT {host}:443 HTTP/1.1\r\n\r\n".encode()); await w.drain()
        return r,w,await r.readuntil(b"\r\n\r\n")
    async def test_live_tunnel_revoked_offline(self):
        self.p["mode"]="allowlist"
        self.p["exceptions"]=[{"domain":"lesson.net","until":time.time()+300}]
        r,w,resp=await self.open("room.lesson.net");self.assertIn(b"200",resp)
        w.write(b"opaque payload");await w.drain()
        self.assertEqual(await r.readexactly(14),b"opaque payload")
        self.p["exceptions"][0]["until"]=0
        self.f.recheck();self.assertEqual(await asyncio.wait_for(r.read(),1),b"")
        w.close();await w.wait_closed()
        r,w,resp=await self.open("room.lesson.net");self.assertIn(b"403",resp);w.close();await w.wait_closed()
    async def test_loopback_dns_denied(self):
        with self.assertRaises(Denied):await connect_host("localhost",443)
