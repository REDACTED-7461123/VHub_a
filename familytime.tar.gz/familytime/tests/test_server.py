import asyncio
import base64
import io
import secrets
import tempfile
import time
import unittest
from datetime import datetime
from pathlib import Path
from zoneinfo import ZoneInfo
from aiohttp.test_utils import TestClient,TestServer
from server.app import create_app

class API(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.tmp=tempfile.TemporaryDirectory()
        self.app=create_app(Path(self.tmp.name)/"db","Europe/Istanbul")
        self.app["store"].set_password("test household password")
        self.client=TestClient(TestServer(self.app));await self.client.start_server()
        self.h={"X-Family-Request":"1"}
    async def asyncTearDown(self):
        await self.client.close();self.tmp.cleanup()
    async def post(self,path,body,headers=None):
        return await self.client.post(path,json=body,headers=self.h if headers is None else headers)
    async def login(self):
        r=await self.post("/api/login",{"password":"test household password"})
        k=r.cookies["__Host-family"]
        self.assertTrue(k["secure"] and k["httponly"] and k["samesite"]=="Strict")
        self.h["Cookie"]="__Host-family="+k.value
    async def device(self,name="Home PC"):
        r=await self.post("/api/parent/devices",{"name":name});self.assertEqual(r.status,200);return await r.json()
    async def enroll(self):
        await self.login();d=await self.device();token=secrets.token_urlsafe(32)
        r=await self.post("/api/agent/pair",{"code":d["code"],"token":token})
        self.assertEqual(r.status,200)
        b=await r.json();self.assertEqual(ZoneInfo.from_file(io.BytesIO(base64.b64decode(b["tzfile"]))).utcoffset(datetime(2026,1,1)).total_seconds(),10800)
        return d,token
    async def test_auth_boundaries(self):
        path="/api/parent/devices"
        self.assertEqual((await self.client.get(path)).status,401)
        self.assertEqual((await self.post("/api/login",{"password":"no"})).status,401)
        await self.login()
        self.assertEqual((await self.post(path,{"name":"x"},{"Cookie":self.h["Cookie"]})).status,403)
        self.assertEqual((await self.post(path,{"name":"x"},{**self.h,"Origin":"https://other.test"})).status,403)
        self.assertEqual((await self.post("/api/agent/sync",{})).status,401)
        await self.post("/api/parent/logout",{});self.assertEqual((await self.client.get(path,headers=self.h)).status,401)
    async def test_pairing_retry_and_code_expiry(self):
        d,t=await self.enroll()
        for token,status in ((t,200),(secrets.token_urlsafe(32),403)):
            self.assertEqual((await self.post("/api/agent/pair",{"code":d["code"],"token":token})).status,status)
        fresh=await self.device()
        self.assertEqual((await self.post("/api/agent/pair",{"code":fresh["code"],"token":t})).status,409)
        with self.app["store"].db() as db:db.execute("UPDATE devices SET expiry=0 WHERE id=?",(fresh["id"],))
        self.assertEqual((await self.post("/api/agent/pair",{"code":fresh["code"],"token":t})).status,403)
    async def test_usage_retry_isolation_and_atomic_invalid_batch(self):
        d,t=await self.enroll();other=await self.device("Laptop")
        day=datetime.now(self.app["zone"]).date().isoformat()
        headers={"Authorization":"Bearer "+t,"X-Family-Request":"1"}
        for n in (40,40,10,75):
            r=await self.post("/api/agent/sync",{"status":"active","revision":1,"usage":{day:n},"id":other["id"]},headers);self.assertEqual(r.status,200)
        r=await self.post("/api/agent/sync",{"status":"active","revision":1,"usage":{day:120,"bad":1}},headers);self.assertEqual(r.status,400)
        for dev,total in ((d,75),(other,0)):
            r=await self.client.get("/api/parent/devices/"+dev["id"],headers=self.h)
            b=await r.json();self.assertEqual(b["history"][-1]["seconds"],total);self.assertEqual(b["week"],total)
    async def test_policy_edit_conflict_and_adjustments(self):
        d,t=await self.enroll();path="/api/parent/devices/"+d["id"]
        async def change(action,rev,**kw):return await self.post(path,{"action":action,"revision":rev,**kw})
        a,b=await asyncio.gather(change("adjust",1,minutes=30),change("adjust",1,minutes=30))
        self.assertEqual(sorted([a.status,b.status]),[200,409])
        self.assertEqual((await change("web",2,mode="allowlist",domains=["LESSON.NET"])).status,200)
        self.assertEqual((await change("exception",3,domain="video.net",minutes=10)).status,200)
        self.assertEqual((await change("revoke",4,domain="video.net")).status,200)
        self.assertEqual((await change("adjust",5,minutes=-15)).status,200)
        self.assertEqual((await change("schedule",6,days=[])).status,400)
        r=await self.client.get(path,headers=self.h);b=await r.json()
        self.assertEqual(b["policy"]["domains"],["lesson.net"]);self.assertEqual(b["allowance"]["quota"],135*60)
        changed=await self.post("/api/agent/sync",{"status":"idle","revision":1,"usage":{}},{"X-Family-Request":"1","Authorization":"Bearer "+t})
        self.assertEqual((await changed.json())["policy"],b["policy"])
    async def test_delete_revokes_token(self):
        d,t=await self.enroll();path="/api/parent/devices/"+d["id"]
        await self.post(path,{"action":"remove","revision":1})
        self.assertEqual((await self.post("/api/agent/sync",{},{"Authorization":"Bearer "+t,"X-Family-Request":"1"})).status,401)
    async def test_assets(self):
        for path in ("/","/assets/app.js","/assets/app.css","/assets/icon.svg"):
            resp=await self.client.get(path);self.assertEqual(resp.status,200)
            self.assertIn("frame-ancestors 'none'",resp.headers["Content-Security-Policy"])
        self.assertEqual((await self.client.get("/assets/app.py")).status,404)
