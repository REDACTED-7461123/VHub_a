import tempfile
import unittest
from datetime import datetime
from pathlib import Path
from zoneinfo import ZoneInfo
from familytime.agentstore import Local
from familytime import rules

class Rules(unittest.TestCase):
    def setUp(self):
        self.p=rules.defaults()
        self.now=datetime(2026,11,2,16,0,tzinfo=ZoneInfo("Europe/Istanbul"))
    def test_weekday_and_boundaries(self):
        self.p["days"][0]={"limit":90,"start":960,"end":1260}
        for hour,allowed in [(15,False),(16,True),(20,True),(21,False)]:
            self.assertEqual(rules.allowance(self.p,self.now.replace(hour=hour),0)["allowed"],allowed)
        self.assertEqual(rules.allowance(self.p,self.now.replace(day=3),0)["quota"],7200)
    def test_adjustment_scope(self):
        self.p["adjust"]["2026-11-02"]=-110
        self.assertEqual(rules.allowance(self.p,self.now,599)["remaining"],1)
        self.assertFalse(rules.allowance(self.p,self.now,600)["allowed"])
        self.assertTrue(rules.allowance(self.p,self.now.replace(day=3),600)["allowed"])
    def test_cutoff_warning(self):
        self.p["days"][0]["end"]=961
        self.assertEqual(rules.allowance(self.p,self.now,0)["available"],60)
    def test_invalid_schedule(self):
        with self.assertRaises(ValueError):rules.days([{"start":120,"end":60,"limit":5}]*7)
        with self.assertRaises(ValueError):rules.days([])
    def test_midnight_idle_suspend_and_resume(self):
        self.assertEqual(rules.charge("active","active",2,2,.5),.5)
        self.assertEqual(rules.charge("active","active",2,3602,50),0)
        self.assertEqual(rules.charge(None,"active",2,2,50),0)
        for state in ("idle","locked","away","restricted"):
            self.assertEqual(rules.charge(state,"active",2,2,40),0)
            self.assertEqual(rules.charge("active",state,2,2,40),0)
    def test_dst(self):
        z=ZoneInfo("America/New_York")
        self.p["days"][6]={"limit":1440,"start":0,"end":180}
        for d,hours in [(datetime(2026,3,8,0,tzinfo=z),2),(datetime(2026,11,1,0,tzinfo=z),4)]:
            self.assertEqual(rules.allowance(self.p,d,0)["available"],hours*3600)
    def test_domains(self):
        self.assertEqual(rules.domain(" *.BÜCHER.de. "), "xn--bcher-kva.de")
        for bad in ("http://example.com","a..test","foo.bar:443","127.0.0.1","*","com","f-.test"):
            with self.assertRaises(ValueError):rules.domain(bad)
    def test_exception_expiry(self):
        self.p["domains"]=["example.net"]
        self.assertFalse(rules.permits("a.example.net",self.p,3))
        self.assertTrue(rules.permits("fakeexample.net",self.p,3))
        self.p["exceptions"]=[{"domain":"edu.example.net","until":10}]
        self.assertTrue(rules.permits("a.edu.example.net",self.p,9))
        self.assertFalse(rules.permits("a.edu.example.net",self.p,10))
        self.p["mode"]="allowlist"
        self.assertTrue(rules.permits("example.net",self.p,11))
        self.assertFalse(rules.permits("other.net",self.p,11))
    def test_offline_journal_restart_and_older_ack(self):
        with tempfile.TemporaryDirectory() as folder:
            path=Path(folder)/"agent.db"
            s=Local(path); s.add("2026-10-01",2.4); snap=s.pending()
            s.add("2026-10-01",2.4); s.ack(snap); s.db.close()
            s=Local(path); self.assertEqual(s.pending(),{"2026-10-01":4})
            s.ack(s.pending()); self.assertEqual(s.pending(),{}); self.assertEqual(s.used("2026-10-01"),4)
            s.db.close()
