#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "$0")"
python3 - <<'PY'
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
ip=next(line.split('=',1)[1] for line in Path('.env').read_text().splitlines() if line.startswith('FT_LAN_IP='))
with ZipFile('windows-client.zip','w',ZIP_DEFLATED) as z:
    for pattern in ('familytime/*.py','windows/*.ps1','windows/*.py','windows/*.cs','windows/*.cmd'):
        for p in sorted(Path('.').glob(pattern)):
            z.write(p)
    z.writestr('windows/server-url.txt',f'http://{ip}:8443')
    z.write('docs/WINDOWS.md','README-WINDOWS.md')
print('Windows installer bundle: windows-client.zip')
PY
