#requires -RunAsAdministrator
$ErrorActionPreference='Stop'
$root=Join-Path $env:ProgramFiles 'Familytime'
. "$root\Policy.ps1"
if (Get-Service Familytime -ErrorAction SilentlyContinue) {
    Stop-Service Familytime
    & "$env:SystemRoot\System32\sc.exe" delete Familytime
    if ($LASTEXITCODE) { throw 'Service removal failed.' }
}
if ((Test-Path "$root\config.json") -and (Test-Path "$root\state\agent.db") -and (Test-Path "$root\python.path")) {
    $python=(Get-Content "$root\python.path" -Raw).Trim()
    & $python -I -B "$root\runner.py" recover
    if ($LASTEXITCODE) { throw 'Account recovery failed. See README before deleting the state folder.' }
}
Remove-FamilyPolicy
Remove-Item $root -Recurse -Force
Write-Host 'Removed Familytime. Restart browsers. The parent dashboard retains history.'
