#requires -RunAsAdministrator
#requires -Version 5.1
$ErrorActionPreference='Stop'
$root=Join-Path $env:ProgramFiles 'Familytime'
$service=Get-CimInstance Win32_Service -Filter "Name='Familytime'"
if ($service.State -ne 'Running' -or $service.StartMode -ne 'Auto' -or $service.StartName -ne 'LocalSystem') { throw 'Service is missing or misconfigured.' }
$config=Get-Content "$root\config.json" -Raw | ConvertFrom-Json
$user=Get-LocalUser -SID $config.sid
if (@(Get-LocalGroupMember -SID 'S-1-5-32-544' | ForEach-Object { $_.SID.Value }) -contains $config.sid) { throw 'Managed child has local administrator access.' }
$listener=Get-NetTCPConnection -State Listen -LocalPort 17841
if ($listener.LocalAddress -ne '127.0.0.1') { throw 'Unexpected filter listener.' }
$process=Get-CimInstance Win32_Process -Filter "ProcessId=$($listener.OwningProcess)"
if ($process.ParentProcessId -ne $service.ProcessId) { throw 'Proxy owner is not the service worker.' }
foreach ($path in 'HKLM:\SOFTWARE\Policies\Google\Chrome','HKLM:\SOFTWARE\Policies\Microsoft\Edge') {
    $p=(Get-ItemProperty $path).ProxySettings | ConvertFrom-Json
    if ($p.ProxyServer -ne 'http://127.0.0.1:17841' -or $p.ProxyMode -ne 'fixed_servers') { throw "Unexpected proxy at $path" }
}
$ff=Get-ItemProperty 'HKLM:\SOFTWARE\Policies\Mozilla\Firefox\Proxy'
if ($ff.Locked -ne 1 -or $ff.SSLProxy -ne '127.0.0.1:17841') { throw 'Unexpected Firefox policy.' }
if (Test-Path "$root\state\strict") {
    $fw=Get-NetFirewallRule -PolicyStore ActiveStore -Name 'Familytime-Child-Egress'
    if ($fw.Enabled -ne 'True' -or $fw.Action -ne 'Block' -or $fw.Direction -ne 'Outbound') { throw 'Child outbound firewall rule inactive.' }
    if (@(Get-NetFirewallProfile | Where-Object { !$_.Enabled }).Count) { throw 'A firewall profile is disabled.' }
    if (($fw | Get-NetFirewallSecurityFilter).LocalUser -notmatch [regex]::Escape($config.sid)) { throw 'Unexpected firewall user filter.' }
}
$acl=Get-Acl $root
if (!$acl.AreAccessRulesProtected) { throw 'Installation ACL inherits permissions.' }
foreach ($entry in $acl.Access) {
    $sid=$entry.IdentityReference.Translate([Security.Principal.SecurityIdentifier]).Value
    if ($entry.AccessControlType -eq 'Allow' -and $sid -notin 'S-1-5-18','S-1-5-32-544') { throw "Unexpected allow entry for $sid" }
}
Write-Host "Service, ownership, local policy and ACL checks passed for $($user.Name). Continue the browser and account checks in README-WINDOWS.md."
