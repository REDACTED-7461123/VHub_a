#requires -RunAsAdministrator
#requires -Version 5.1
[CmdletBinding()]
param([switch]$Update, [switch]$BrowserOnly)
$ErrorActionPreference = 'Stop'
if (![Environment]::Is64BitProcess) { throw 'Use 64-bit Windows PowerShell.' }
$root = Join-Path $env:ProgramFiles 'Familytime'
$source = Split-Path $PSScriptRoot -Parent
$cmd = Join-Path $env:SystemRoot 'System32\sc.exe'
function Native([string]$Exe, [string[]]$ArgList) {
    & $Exe @ArgList
    if ($LASTEXITCODE -ne 0) { throw "$Exe failed with exit code $LASTEXITCODE" }
}
function Copy-Code([string]$dest) {
    Copy-Item (Join-Path $source 'familytime') $dest -Recurse -Force
    foreach ($file in 'runner.py','Uninstall.ps1','Policy.ps1','Service.cs') {
        Copy-Item (Join-Path $PSScriptRoot $file) $dest -Force
    }
    $compiler = "$env:windir\Microsoft.NET\Framework64\v4.0.30319\csc.exe"
    Native $compiler @('/nologo','/target:exe','/platform:x64','/reference:System.ServiceProcess.dll',"/out:$dest\Familytime.exe","$dest\Service.cs")
}
if ($Update) {
    if (!(Get-Service Familytime -ErrorAction SilentlyContinue)) { throw 'Install Familytime first.' }
    $stage = Join-Path $root 'staging'
    $backup = Join-Path $root 'previous'
    Remove-Item $stage,$backup -Recurse -Force -ErrorAction SilentlyContinue
    New-Item $stage,$backup -ItemType Directory | Out-Null
    Copy-Code $stage
    $python = (Get-Content "$root\python.path" -Raw).Trim()
    Native $python @('-I','-m','compileall','-q',$stage)
    Stop-Service Familytime
    try {
        foreach ($item in (Get-ChildItem $stage)) {
            $old = Join-Path $root $item.Name
            if (Test-Path $old) { Move-Item $old $backup }
            Move-Item $item.FullName $root
        }
        Remove-Item "$root\state\ready" -Force -ErrorAction SilentlyContinue
        Start-Service Familytime
        for ($n=0;$n -lt 20 -and !(Test-Path "$root\state\ready");$n++) { Start-Sleep 1 }
        if (!(Test-Path "$root\state\ready")) { throw 'Updated agent did not start.' }
        Remove-Item $stage,$backup -Recurse -Force
        Write-Host 'Update installed.'
    } catch {
        Stop-Service Familytime -ErrorAction SilentlyContinue
        foreach ($item in (Get-ChildItem $backup)) {
            Remove-Item (Join-Path $root $item.Name) -Recurse -Force -ErrorAction SilentlyContinue
            Move-Item $item.FullName $root
        }
        Start-Service Familytime
        throw
    }
    return
}
if ((Test-Path $root) -or (Get-Service Familytime -ErrorAction SilentlyContinue)) { throw 'Installation already exists. Use -Update or the installed Uninstall.ps1.' }
$python = @(Get-ChildItem "$env:ProgramFiles\Python3*\python.exe" -File -ErrorAction SilentlyContinue | Sort-Object FullName -Descending | Select-Object -ExpandProperty FullName)[0]
if (!$python) { throw 'Install 64-bit CPython 3.11 or later for ALL users in Program Files, then rerun.' }
Native $python @('-I','-c','import sys; sys.exit(0 if sys.version_info >= (3,11) and sys.maxsize > 2**32 else 1)')
$suggested = ''
if (Test-Path "$PSScriptRoot\server-url.txt") { $suggested = (Get-Content "$PSScriptRoot\server-url.txt" -Raw).Trim() }
$server = (Read-Host "Dashboard HTTPS URL [$suggested]").Trim().TrimEnd('/')
if (!$server) { $server = $suggested }
$uri = [uri]$server
if (!$uri.IsAbsoluteUri -or $uri.Scheme -ne 'https' -or $uri.UserInfo -or $uri.Query -or $uri.Fragment -or $uri.AbsolutePath -ne '/') { throw 'Enter the HTTPS origin only.' }
$ca = Join-Path $PSScriptRoot 'household-ca.crt'
if (!(Test-Path $ca)) { throw 'Copy household-ca.crt from Ubuntu into the windows folder first.' }
Get-LocalUser | Select-Object Name,Enabled,PrincipalSource | Format-Table
$user = Get-LocalUser -Name (Read-Host 'Exact local username of the child').Trim()
$admins = @(Get-LocalGroupMember -SID 'S-1-5-32-544' | ForEach-Object { $_.SID.Value })
if (!$user.Enabled -or $user.PrincipalSource -ne 'Local' -or $user.SID.Value -in $admins -or $user.SID.Value -eq [Security.Principal.WindowsIdentity]::GetCurrent().User.Value -or [int]($user.SID.Value.Split('-')[-1]) -lt 1000) { throw 'Use an enabled, local standard child account and a separate parent administrator.' }
if (@(Get-NetFirewallProfile | Where-Object { !$_.Enabled }).Count) { throw 'Enable Windows Defender Firewall in all three profiles before installation.' }
if (Get-NetFirewallRule -Name 'Familytime-Child-Egress' -ErrorAction SilentlyContinue) { throw 'A conflicting Familytime firewall rule already exists.' }
. (Join-Path $PSScriptRoot 'Policy.ps1')
Assert-PolicyFree
$secureCode = Read-Host 'Pairing code from the dashboard' -AsSecureString
$ptr = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($secureCode)
try { $code = [Runtime.InteropServices.Marshal]::PtrToStringBSTR($ptr) } finally { [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($ptr) }
New-Item $root -ItemType Directory | Out-Null
try {
    Native "$env:SystemRoot\System32\icacls.exe" @($root,'/inheritance:r','/grant:r','*S-1-5-18:(OI)(CI)F','*S-1-5-32-544:(OI)(CI)F')
    New-Item "$root\state" -ItemType Directory | Out-Null
    Copy-Code $root
    Copy-Item $ca $root
    Set-Content "$root\python.path" $python -Encoding UTF8
    @{sid=$user.SID.Value;server=$server} | ConvertTo-Json | Set-Content "$root\config.json" -Encoding UTF8
    $code | & $python -I -B "$root\runner.py" pair
    if ($LASTEXITCODE) { throw 'Pairing failed. Check the address, certificate and code.' }
    $code = $null
    Set-FamilyPolicy $user.SID.Value -BrowserOnly:$BrowserOnly
    New-Service -Name Familytime -DisplayName 'Familytime parental controls' -BinaryPathName ('"'+$root+'\Familytime.exe"') -StartupType Automatic | Out-Null
    Native $cmd @('failure','Familytime','reset=','86400','actions=','restart/3000/restart/5000/restart/10000')
    Native $cmd @('failureflag','Familytime','1')
    Start-Service Familytime
    for ($n=0;$n -lt 20 -and !(Test-Path "$root\state\ready");$n++) { Start-Sleep 1 }
    if (!(Test-Path "$root\state\ready")) { throw 'Service failed its startup check. Inspect the printed error and use the Windows checklist.' }
    Write-Host 'Familytime installed. Close and reopen all browsers once, then run the acceptance checks.'
} catch {
    $problem=$_
    if (Test-Path "$root\state\service.log") { Get-Content "$root\state\service.log" -Tail 15 }
    if ((Test-Path "$root\Uninstall.ps1") -and (Test-Path "$root\Policy.ps1")) { & "$root\Uninstall.ps1" }
    else { Remove-Item $root -Recurse -Force }
    throw $problem
}
