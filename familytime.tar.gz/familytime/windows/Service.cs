using System;
using System.Diagnostics;
using System.IO;
using System.ServiceProcess;

public sealed class FamilytimeService : ServiceBase
{
    private Process worker;
    private volatile bool stopping;
    public FamilytimeService() { ServiceName = "Familytime"; }
    protected override void OnStart(string[] args)
    {
        string root = AppDomain.CurrentDomain.BaseDirectory;
        string python = File.ReadAllText(Path.Combine(root, "python.path")).Trim();
        var info = new ProcessStartInfo(python, "-I -B \"" + Path.Combine(root, "runner.py") + "\"");
        info.WorkingDirectory = root;
        info.UseShellExecute = false;
        info.CreateNoWindow = true;
        worker = new Process();
        worker.StartInfo = info;
        worker.EnableRaisingEvents = true;
        worker.Exited += delegate { if (!stopping) Environment.Exit(1); };
        worker.Start();
    }
    protected override void OnStop()
    {
        stopping = true;
        if (worker != null && !worker.HasExited)
        {
            worker.Kill();
            worker.WaitForExit(6000);
        }
    }
    public static void Main() { ServiceBase.Run(new FamilytimeService()); }
}
