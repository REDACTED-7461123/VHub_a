# -I disables user site packages, working-directory imports and PYTHON* overrides.
import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
from familytime.agent import main
main()
