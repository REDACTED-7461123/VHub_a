$chromium = @('HKLM:\SOFTWARE\Policies\Google\Chrome','HKLM:\SOFTWARE\Policies\Microsoft\Edge')
$firefox = 'HKLM:\SOFTWARE\Policies\Mozilla\Firefox\Proxy'
$proxyJson = '{"ProxyMode":"fixed_servers","ProxyServer":"http://127.0.0.1:17841","ProxyBypassList":"<-loopback>"}'
function Assert-PolicyFree {
    foreach ($path in $chromium) {
        foreach ($key in 'ProxySettings','ProxyMode','ProxyServer','ProxyPacUrl','ProxyBypassList','QuicAllowed') {
            if ((Get-ItemProperty -Path $path -Name $key -ErrorAction SilentlyContinue) -ne $null) { throw "Existing browser policy at $path ($key). Resolve the conflict first." }
        }
    }
    if (Test-Path $firefox) { throw 'Existing Firefox proxy policy. Resolve the conflict first.' }
}
function Set-FamilyPolicy([string]$sid, [switch]$BrowserOnly) {
    # Record ownership before changing anything; installation refuses pre-existing settings.
    New-Item "$root\state\owns-policy" -ItemType File -Force | Out-Null
    foreach ($path in $chromium) {
        if (!(Test-Path $path)) { New-Item -Path $path -Force | Out-Null }
        New-ItemProperty -Path $path -Name ProxySettings -Value $proxyJson -PropertyType String -Force | Out-Null
        New-ItemProperty -Path $path -Name QuicAllowed -Value 0 -PropertyType DWord -Force | Out-Null
    }
    New-Item $firefox -Force | Out-Null
    New-ItemProperty -Path $firefox -Name Mode -Value 'manual' -PropertyType String | Out-Null
    New-ItemProperty -Path $firefox -Name Locked -Value 1 -PropertyType DWord | Out-Null
    New-ItemProperty -Path $firefox -Name HTTPProxy -Value '127.0.0.1:17841' -PropertyType String | Out-Null
    New-ItemProperty -Path $firefox -Name SSLProxy -Value '127.0.0.1:17841' -PropertyType String | Out-Null
    New-ItemProperty -Path $firefox -Name Passthrough -Value '' -PropertyType String | Out-Null
    if ($BrowserOnly) { return }
    New-Item "$root\state\strict" -ItemType File -Force | Out-Null
    # Public and LAN destinations, IPv4 and IPv6; the loopback proxy is the only intended egress.
    $remote = @('0.0.0.0-126.255.255.255','128.0.0.0-255.255.255.255','::2-ffff:ffff:ffff:ffff:ffff:ffff:ffff:ffff')
    New-NetFirewallRule -Name 'Familytime-Child-Egress' -DisplayName 'Familytime - child direct network access' -Direction Outbound -Action Block -LocalUser "D:(A;;CC;;;$sid)" -RemoteAddress $remote -Profile Any -Enabled True | Out-Null
}
function Remove-FamilyPolicy {
    if (!(Test-Path "$root\state\owns-policy")) { return }
    if (Get-NetFirewallRule -Name 'Familytime-Child-Egress' -ErrorAction SilentlyContinue) {
        Remove-NetFirewallRule -Name 'Familytime-Child-Egress'
    }
    foreach ($path in $chromium) {
        foreach ($key in 'ProxySettings','QuicAllowed') {
            if (Get-ItemProperty -Path $path -Name $key -ErrorAction SilentlyContinue) { Remove-ItemProperty $path $key }
        }
    }
    if (Test-Path $firefox) { Remove-Item $firefox -Recurse -Force }
}
