"""Loopback HTTP/1.1 forward proxy. HTTPS is tunneled without inspecting TLS."""
import asyncio
import ipaddress
import re
import socket
import time
from urllib.parse import urlsplit

from .rules import permits

class Denied(Exception):
    pass

LAN_RANGES = tuple(ipaddress.ip_network(cidr) for cidr in
                   ("10.0.0.0/8", "172.16.0.0/12", "192.168.0.0/16", "fc00::/7"))

def routable_destination(ip):
    # Permit household web servers while keeping loopback and link-local services private.
    if ip.is_multicast or getattr(ip, "ipv4_mapped", None):
        return False
    return ip.is_global or any(ip in network for network in LAN_RANGES)

async def connect_host(host, port):
    records = await asyncio.get_running_loop().getaddrinfo(host, port, type=socket.SOCK_STREAM)
    for family, _, _, _, addr in records:
        ip = ipaddress.ip_address(addr[0])
        if not routable_destination(ip):
            raise Denied()
    for family, _, _, _, addr in records:
        try:
            return await asyncio.wait_for(asyncio.open_connection(addr[0], port, family=family), 4)
        except (OSError, asyncio.TimeoutError):
            continue
    raise OSError("No route")

async def pump(source, dest):
    while chunk := await source.read(65536):
        dest.write(chunk)
        await dest.drain()

async def tunnel(left, right, upstream, downstream):
    jobs = [asyncio.create_task(pump(left,upstream)),asyncio.create_task(pump(right,downstream))]
    try:
        await asyncio.wait(jobs,return_when=asyncio.FIRST_COMPLETED)
    finally:
        for job in jobs:
            job.cancel()
        await asyncio.gather(*jobs,return_exceptions=True)

def parse_head(raw):
    lines=raw[:-4].split(b"\r\n")
    method,target,version=lines[0].decode("ascii").split(" ")
    if version not in ("HTTP/1.1","HTTP/1.0") or not re.fullmatch("[A-Z]{1,16}",method):
        raise ValueError()
    addr=urlsplit("//"+target if method=="CONNECT" else target)
    if not addr.hostname or addr.username is not None or addr.password is not None or addr.fragment:
        raise ValueError()
    if method=="CONNECT":
        if addr.path or addr.query or addr.port!=443:
            raise Denied()
    elif addr.scheme!="http" or addr.port not in (80,None):
        raise Denied()
    host=addr.hostname.lower().rstrip(".")
    if not re.fullmatch(r"[a-z0-9._-]{1,253}",host) or not all(re.fullmatch(r"[a-z0-9](?:[a-z0-9_-]{0,61}[a-z0-9])?",part) for part in host.split(".")):
        raise Denied()
    try:
        ipaddress.ip_address(host)
    except ValueError:
        pass
    else:
        raise Denied()
    headers={}
    for line in lines[1:]:
        key,sep,val=line.partition(b":")
        key=key.lower()
        if not sep or not re.fullmatch(rb"[!#$%&'*+.^_`|~0-9a-z-]+",key) or any(c<32 and c!=9 or c==127 for c in val):
            raise ValueError()
        if key in headers and key in (b"host",b"content-length",b"transfer-encoding",b"connection"):
            raise ValueError()
        headers[key]=headers.get(key,b"")+ (b", " if key in headers else b"")+val.strip()
    # Each plain HTTP request gets a separate upstream connection and exactly one body.
    if b"transfer-encoding" in headers or b"upgrade" in headers or (b"expect" in headers):
        raise ValueError()
    length=headers.pop(b"content-length",b"0")
    if not re.fullmatch(rb"[0-9]{1,10}",length) or (method=="CONNECT" and int(length)):
        raise ValueError()
    skip={b"host",b"connection",b"keep-alive",b"proxy-authorization",b"proxy-connection",b"te",b"trailer"}
    skip.update(x.strip().lower() for x in headers.get(b"connection",b"").split(b","))
    path=(addr.path or "/")+("?"+addr.query if addr.query else "")
    if any(ord(c)<=32 or ord(c)==127 for c in target) or not path.startswith("/") or path.startswith("//"):
        raise ValueError()
    head=f"{method} {path} HTTP/1.1\r\nHost: {host}\r\nConnection: close\r\n".encode()
    head+=b"".join(k+b": "+v+b"\r\n" for k,v in headers.items() if k not in skip)
    if int(length) or method in ("POST","PUT","PATCH"):
        head+=b"Content-Length: "+str(int(length)).encode()+b"\r\n"
    return method,host,int(length),head+b"\r\n"

class WebFilter:
    def __init__(self, policy, connect=connect_host):
        self.policy=policy
        self.connect=connect
        self.live={}
        self.busy=0
    def allowed(self,host):
        return permits(host,self.policy(),time.time())
    def recheck(self):
        for client,(host,upstream) in tuple(self.live.items()):
            if not self.allowed(host):
                client.close()
                upstream.close()
    async def handle(self,reader,writer):
        upstream=None
        sent=False
        self.busy+=1
        try:
            if self.busy>256:
                raise Denied()
            raw=await asyncio.wait_for(reader.readuntil(b"\r\n\r\n"),8)
            method,host,length,head=parse_head(raw)
            if not self.allowed(host):
                raise Denied()
            remote,upstream=await asyncio.wait_for(self.connect(host,443 if method=="CONNECT" else 80),10)
            if not self.allowed(host):
                raise Denied()
            self.live[writer]=(host,upstream)
            if method=="CONNECT":
                writer.write(b"HTTP/1.1 200 Connection Established\r\n\r\n")
                await writer.drain()
                sent=True
                await tunnel(reader,remote,upstream,writer)
            else:
                upstream.write(head)
                while length:
                    chunk=await asyncio.wait_for(reader.read(min(length,65536)),30)
                    if not chunk:
                        return
                    upstream.write(chunk)
                    await upstream.drain()
                    length-=len(chunk)
                await upstream.drain()
                sent=True
                await pump(remote,writer)
        except (OSError, ValueError, UnicodeError, Denied, asyncio.TimeoutError,asyncio.IncompleteReadError,asyncio.LimitOverrunError) as e:
            if not sent:
                status="403 Forbidden" if isinstance(e,Denied) else "502 Bad Gateway" if isinstance(e,OSError) else "400 Bad Request"
                writer.write(f"HTTP/1.1 {status}\r\nConnection: close\r\nContent-Length: 0\r\n\r\n".encode())
        finally:
            self.live.pop(writer,None)
            if upstream:
                upstream.close()
            writer.close()
            self.busy-=1
