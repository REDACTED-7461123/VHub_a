import json
import sqlite3

class Local:
    def __init__(self,path):
        self.db=sqlite3.connect(path)
        self.db.execute("PRAGMA journal_mode=WAL")
        self.db.executescript("""
        CREATE TABLE IF NOT EXISTS kv(k TEXT PRIMARY KEY,v TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS daily(day TEXT PRIMARY KEY,seconds REAL NOT NULL,acked INTEGER DEFAULT -1);
        """)
    def get(self,k,default=None):
        row=self.db.execute("SELECT v FROM kv WHERE k=?",(k,)).fetchone()
        return json.loads(row[0]) if row else default
    def put(self,k,v):
        with self.db:
            self.db.execute("REPLACE INTO kv VALUES(?,?)",(k,json.dumps(v)))
    def add(self,day,seconds):
        with self.db:
            self.db.execute("""INSERT INTO daily(day,seconds) VALUES(?,?) ON CONFLICT(day)
                DO UPDATE SET seconds=min(90000,daily.seconds+excluded.seconds)""",(day,seconds))
    def used(self,day):
        r=self.db.execute("SELECT seconds FROM daily WHERE day=?",(day,)).fetchone()
        return int(r[0]) if r else 0
    def pending(self):
        return dict(self.db.execute("SELECT day,cast(seconds AS integer) AS n FROM daily WHERE cast(seconds AS integer)>acked ORDER BY day LIMIT 128"))
    def ack(self,snapshot):
        with self.db:
            self.db.executemany("UPDATE daily SET acked=max(acked,?) WHERE day=?",((v,k) for k,v in snapshot.items()))
