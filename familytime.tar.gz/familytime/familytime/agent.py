import asyncio
import base64
import io
import json
import logging
import os
import secrets
import socket
import sys
import time
import urllib.request
from datetime import datetime
from logging.handlers import RotatingFileHandler
from pathlib import Path
from zoneinfo import ZoneInfo
if sys.platform == "win32":
    from . import winapi as win
else:
    win = None  # Portable rule, store and transport tests supply a simulated desktop.
from .agentstore import Local
from .rules import allowance, charge
from .proxy import WebFilter

ROOT=Path(__file__).resolve().parents[1]
STATE=ROOT/"state"
def rpc(config,endpoint,body,token=None):
    # Existing installations keep their saved host and port when updated to HTTP.
    server = config["server"]
    if server.startswith("https://"):
        server = "http://" + server[len("https://"):]
    if not server.startswith("http://"):
        raise ValueError("Expected an HTTP dashboard address")
    opener = urllib.request.build_opener(urllib.request.ProxyHandler({}), NoRedirect())
    headers={"Content-Type":"application/json","X-Family-Request":"1"}
    if token:
        headers["Authorization"]="Bearer "+token
    req=urllib.request.Request(server+endpoint,json.dumps(body).encode(),headers)
    with opener.open(req,timeout=8) as response:
        return json.load(response)

class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self,*args):
        return None

def timezone(bundle):
    return ZoneInfo.from_file(io.BytesIO(base64.b64decode(bundle["tzfile"])),key=bundle["zone"])

def gate(local,user,restrict):
    # Persist ownership first so a crash after disabling cannot strand the child.
    owned=local.get("disabled",False)
    if restrict:
        if not owned and not (win.flags(user)&2):
            local.put("disabled",True)
            owned=True
        if owned:
            win.set_disabled(user,True)
    elif owned:
        win.set_disabled(user,False)
        local.put("disabled",False)

class Agent:
    def __init__(self,local,config):
        self.local=local
        self.config=config
        self.bundle=local.get("bundle")
        self.zone=timezone(self.bundle)
        self.status="away"
        self.proxy=WebFilter(lambda:self.bundle["policy"])
        self.warned=None
        self.previous=None
        self.last_tick=None
        self.last_wall=None
    async def sync(self):
        while True:
            snapshot=self.local.pending()
            payload={"status":self.status,"usage":snapshot,"revision":self.bundle["policy"]["revision"]}
            try:
                b=await asyncio.to_thread(rpc,self.config,"/api/agent/sync",payload,self.local.get("token"))
                if b["id"]!=self.bundle["id"]:
                    raise RuntimeError("Unexpected device identity")
                if b!=self.bundle:
                    zone=timezone(b)
                    self.local.put("bundle",b)
                    self.bundle,self.zone=b,zone
                    self.proxy.recheck()
                self.local.ack(snapshot)
            except Exception as exc:
                logging.warning("Sync unavailable (%s)",type(exc).__name__)
            await asyncio.sleep(15)
    def sample(self, now, tick, filter_ready):
        local_time = datetime.fromtimestamp(now, self.zone)
        day = local_time.date().isoformat()
        user = win.username(self.config["sid"])
        elapsed = 0 if self.last_tick is None else tick - self.last_tick
        wall_elapsed = 0 if self.last_wall is None else now - self.last_wall
        self.last_tick, self.last_wall = tick, now
        self.proxy.recheck()
        try:
            state, sessions = win.observe(user)
        except (OSError, RuntimeError):
            logging.exception("Session query failed; restricting child sign-in")
            gate(self.local, user, True)
            self.status = "error"
            self.previous = None
            return

        midnight = local_time.replace(hour=0, minute=0, second=0, microsecond=0, fold=0)
        amount = charge(self.previous, state, elapsed, wall_elapsed, now - midnight.timestamp())
        new_day = self.local.get("last_day") != day
        if new_day or amount:
            self.local.add(day, amount)
        if new_day:
            self.local.put("last_day", day)

        budget = allowance(self.bundle["policy"], local_time, self.local.used(day))
        healthy = filter_ready and state != "error"
        allowed = healthy and budget["allowed"]
        gate(self.local, user, not allowed)
        if not allowed:
            win.lock_sessions(sessions)
        self.status = state if allowed else ("restricted" if healthy else "error")
        self.previous = self.status
        if healthy and not (STATE / "ready").exists():
            (STATE / "ready").touch()

        left = budget["available"]
        bucket = 1 if left <= 60 else 5 if left <= 300 else None
        warning = (day, bucket, tuple(sessions))
        if bucket and allowed and state == "active" and self.warned != warning:
            win.warn(sessions, left)
            self.warned = warning
        if not bucket or not sessions:
            self.warned = None

    async def run(self):
        proxy=None
        def listener():
            sock=socket.socket(socket.AF_INET,socket.SOCK_STREAM)
            try:
                sock.setsockopt(socket.SOL_SOCKET,socket.SO_EXCLUSIVEADDRUSE,1)
                sock.bind(("127.0.0.1",17841))
                sock.listen()
                sock.setblocking(False)
                return sock
            except BaseException:
                sock.close()
                raise
        worker=asyncio.create_task(self.sync())
        try:
            while True:
                if proxy is None:
                    try:
                        proxy=await asyncio.start_server(self.proxy.handle,sock=listener(),limit=32768)
                    except OSError:
                        logging.error("Filter port unavailable; restricting child sign-in")
                self.sample(time.time(), win.active_clock(), proxy is not None)
                if worker.done():
                    worker.result()
                await asyncio.sleep(2)
        finally:
            worker.cancel()
            if proxy:
                proxy.close()
                await proxy.wait_closed()

def main():
    logger=logging.getLogger()
    logger.setLevel(logging.INFO)
    logger.addHandler(RotatingFileHandler(STATE/"service.log",maxBytes=131072,backupCount=2))
    local=Local(STATE/"agent.db")
    config=json.loads((ROOT/"config.json").read_text(encoding="utf-8-sig"))
    if sys.argv[1:] == ["pair"]:
        token=local.get("token") or secrets.token_urlsafe(32)
        local.put("token",token)
        code=sys.stdin.readline().strip()
        b=rpc(config,"/api/agent/pair",{"code":code,"token":token})
        timezone(b)
        local.put("bundle",b)
    elif sys.argv[1:] == ["replay"]:
        with local.db:
            local.db.execute("UPDATE daily SET acked=-1")
    elif sys.argv[1:] == ["recover"]:
        gate(local,win.username(config["sid"]),False)
    else:
        try:
            asyncio.run(Agent(local,config).run())
        except BaseException:
            logging.exception("Service stopped unexpectedly")
            raise
