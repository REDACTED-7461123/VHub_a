"""Shared rules. Times in a weekday rule are wall-clock minutes, end exclusive."""
import re
from datetime import timedelta

VERSION = "1.0.0"
STATES = {"active", "idle", "locked", "away", "restricted", "error"}
LABEL = re.compile(r"[a-z0-9](?:[a-z0-9_-]{0,61}[a-z0-9])?")

def integer(value, lo, hi):
    if type(value) is not int or not lo <= value <= hi:
        raise ValueError(f"Expected a whole number from {lo} to {hi}.")
    return value

def domain(value):
    if not isinstance(value, str):
        raise ValueError("Enter a domain name.")
    host = value.strip().lower().removeprefix("*.").removesuffix(".")
    try:
        host = host.encode("idna").decode("ascii")
    except UnicodeError:
        raise ValueError("Invalid domain.") from None
    if len(host) > 253 or "." not in host or not all(LABEL.fullmatch(x) for x in host.split(".")) or host.split(".")[-1].isdigit():
        raise ValueError("Enter domain names such as example.org, one per line.")
    return host

def defaults():
    return {"days": [{"limit": 120, "start": 0, "end": 1440} for _ in range(7)],
            "mode": "blocklist", "domains": [], "exceptions": [], "adjust": {}, "revision": 1}

def days(data):
    if not isinstance(data, list) or len(data) != 7:
        raise ValueError("Supply one schedule for each weekday.")
    result = []
    for row in data:
        if not isinstance(row, dict):
            raise ValueError("Invalid schedule.")
        start, end = integer(row.get("start"), 0, 1439), integer(row.get("end"), 1, 1440)
        if end <= start:
            raise ValueError("End must follow start. Split overnight hours over two days.")
        result.append(dict(limit=integer(row.get("limit"), 0, 1440), start=start, end=end))
    return result

def web(data):
    if data.get("mode") not in ("blocklist", "allowlist"):
        raise ValueError("Choose a website filtering mode.")
    values = data.get("domains")
    if not isinstance(values, list) or len(values) > 500:
        raise ValueError("Use at most 500 domains.")
    return {"mode": data["mode"], "domains": sorted(set(map(domain, values)))}

def permits(host, policy, now):
    host = host.lower().rstrip(".")
    def matches(name):
        return host == name or host.endswith("." + name)
    if any(e["until"] > now and matches(e["domain"]) for e in policy["exceptions"]):
        return True
    listed = any(matches(d) for d in policy["domains"])
    return listed if policy["mode"] == "allowlist" else not listed

def allowance(policy, local, used):
    day = local.date().isoformat()
    rule = policy["days"][local.weekday()]
    quota = max(0, min(1440, rule["limit"] + policy["adjust"].get(day, 0))) * 60
    left = max(0, quota - used)
    minute = local.hour * 60 + local.minute
    inside = rule["start"] <= minute < rule["end"]
    # Use timezone-aware timestamps so elapsed time to the boundary includes DST changes.
    midnight = local.replace(hour=0, minute=0, second=0, microsecond=0, fold=0)
    end = midnight + timedelta(minutes=rule["end"])
    window = max(0, int(end.timestamp() - local.timestamp()))
    return dict(quota=quota, remaining=left, allowed=inside and left > 0,
                available=min(left, window) if inside else 0,
                reason="Outside allowed hours" if not inside else "Daily limit reached" if not left else "")

def charge(previous, current, elapsed, wall_elapsed, seconds_today):
    # Both ends must be active. Never charge a suspended/stalled interval or yesterday's seconds.
    if previous != "active" or current != "active" or not 0 <= elapsed <= 10 or not 0 <= wall_elapsed <= 12:
        return 0
    return max(0, min(elapsed, wall_elapsed, seconds_today))
