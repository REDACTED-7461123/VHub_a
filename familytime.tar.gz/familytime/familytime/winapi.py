"""Windows 10/11 x64 LocalSystem bindings. All returned native buffers are released."""
import ctypes as C
from ctypes import wintypes as W
import os

wts=C.WinDLL("wtsapi32",use_last_error=True)
net=C.WinDLL("netapi32",use_last_error=True)
adv=C.WinDLL("advapi32",use_last_error=True)
kernel=C.WinDLL("kernel32",use_last_error=True)
P=C.c_void_p
D=W.DWORD
I=C.c_int
U=C.c_wchar_p
L=C.c_longlong

def api(lib,name,ret,*args):
    f=getattr(lib,name)
    f.restype=ret
    f.argtypes=list(args)
    return f

def ok(result):
    if not result:
        raise C.WinError(C.get_last_error())
    return result

class Session(C.Structure):
    _fields_=[("id",D),("station",U),("state",I)]

class Info(C.Structure):
    _fields_=[("id",D),("state",I),("flags",W.LONG),("station",C.c_wchar*33),
              ("username",C.c_wchar*21),("domain",C.c_wchar*18),
              ("logon",L),("connect",L),("disconnect",L),("last",L),("now",L),
              ("counters",D*6)]
class Extended(C.Structure):
    _fields_=[("level",D),("session",Info)]
class User1(C.Structure):
    _fields_=[("name",U),("password",U),("age",D),("priv",D),("home",U),
              ("comment",U),("flags",D),("script",U)]

enumerate_sessions=api(wts,"WTSEnumerateSessionsW",W.BOOL,P,D,D,C.POINTER(P),C.POINTER(D))
query=api(wts,"WTSQuerySessionInformationW",W.BOOL,P,D,I,C.POINTER(P),C.POINTER(D))
free=api(wts,"WTSFreeMemory",None,P)
disconnect=api(wts,"WTSDisconnectSession",W.BOOL,P,D,W.BOOL)
logoff=api(wts,"WTSLogoffSession",W.BOOL,P,D,W.BOOL)
message=api(wts,"WTSSendMessageW",W.BOOL,P,D,U,D,U,D,D,D,C.POINTER(D),W.BOOL)
unbiased=api(kernel,"QueryUnbiasedInterruptTime",W.BOOL,C.POINTER(C.c_ulonglong))
from_sid=api(adv,"ConvertStringSidToSidW",W.BOOL,U,C.POINTER(P))
local_free=api(kernel,"LocalFree",P,P)
lookup=api(adv,"LookupAccountSidW",W.BOOL,U,P,U,C.POINTER(D),U,C.POINTER(D),C.POINTER(D))
getuser=api(net,"NetUserGetInfo",D,U,U,D,C.POINTER(P))
setuser=api(net,"NetUserSetInfo",D,U,U,D,P,C.POINTER(D))
netfree=api(net,"NetApiBufferFree",D,P)

def username(sid):
    raw=P()
    ok(from_sid(sid,C.byref(raw)))
    try:
        name,domain=C.create_unicode_buffer(257),C.create_unicode_buffer(257)
        n,m,kind=D(len(name)),D(len(domain)),D()
        ok(lookup(None,raw,name,C.byref(n),domain,C.byref(m),C.byref(kind)))
        if domain.value.casefold()!=os.environ["COMPUTERNAME"].casefold() or kind.value!=1:
            raise RuntimeError("Configured SID is not a local user")
        return name.value
    finally:
        local_free(raw)

def active_clock():
    value=C.c_ulonglong()
    ok(unbiased(C.byref(value)))
    return value.value/10_000_000

def session_value(session,kind):
    buf,size=P(),D()
    ok(query(None,session,kind,C.byref(buf),C.byref(size)))
    try:
        if kind==25:
            if size.value<C.sizeof(Extended):
                raise RuntimeError("Incomplete WTS structure")
            value=Extended.from_buffer_copy(C.string_at(buf,size.value))
            if value.level!=1:
                raise RuntimeError("Unknown WTS level")
            return value.session
        return C.wstring_at(buf) if size.value else ""
    finally:
        free(buf)

def observe(user):
    buf,count=P(),D()
    ok(enumerate_sessions(None,0,1,C.byref(buf),C.byref(count)))
    states=[]
    ids=[]
    try:
        for s in C.cast(buf,C.POINTER(Session))[:count.value]:
            if s.state!=0 or s.id==0:
                continue
            if session_value(s.id,5).casefold()!=user.casefold() or session_value(s.id,7).casefold()!=os.environ["COMPUTERNAME"].casefold():
                continue
            ids.append(s.id)
            try:
                v=session_value(s.id,25)
            except (OSError, RuntimeError):
                states.append("error")
                continue
            if v.flags not in (0,1):
                states.append("error")
                continue
            if v.flags==0:
                states.append("locked")
            elif v.last and (v.now-v.last)>=300*10_000_000:
                states.append("idle")
            else:
                states.append("active")
    finally:
        free(buf)
    return next((state for state in ("error","active","idle","locked") if state in states),"away"),ids

def flags(user):
    buf=P()
    err=getuser(None,user,1,C.byref(buf))
    if err:
        raise C.WinError(err)
    try:
        return C.cast(buf,C.POINTER(User1)).contents.flags
    finally:
        netfree(buf)

def set_disabled(user,disabled):
    old=flags(user)
    new=(old|2) if disabled else (old & ~2)
    if old != new:
        data=D(new)
        err=setuser(None,user,1008,C.byref(data),None)
        if err:
            raise C.WinError(err)

def lock_sessions(ids):
    for i in ids:
        if not disconnect(None,i,False):
            # Some local console configurations reject disconnect. Enforce sign-out instead.
            ok(logoff(None,i,False))

def warn(ids,seconds):
    title="Familytime"
    text=f"About {max(1, (seconds+59)//60)} minute(s) of computer time left. Please save your work."
    for i in ids:
        result=D()
        message(None,i,title,len(title)*2,text,len(text)*2,0x40,20,C.byref(result),False)
