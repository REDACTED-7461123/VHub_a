#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "$0")"
umask 077
for tool in docker openssl python3; do command -v "$tool" >/dev/null || { echo "Install $tool first."; exit 1; }; done
docker compose version >/dev/null
if [[ -e .env || -e private || -e tls || -e data ]]; then
  echo "Existing setup found. Follow README update/recovery instructions. No files changed."; exit 1
fi
guess=$(hostname -I | awk '{print $1}')
read -rp "Ubuntu LAN IPv4 address [$guess]: " ip
ip=${ip:-$guess}
python3 -c 'import ipaddress,sys; ipaddress.IPv4Address(sys.argv[1])' "$ip"
zone=$(cat /etc/timezone 2>/dev/null || timedatectl show -p Timezone --value 2>/dev/null || echo UTC)
read -rp "Household time zone [$zone]: " selected
zone=${selected:-$zone}
python3 -c 'import sys,zoneinfo,re; assert re.fullmatch(r"[A-Za-z0-9_+/.-]+",sys.argv[1]); zoneinfo.ZoneInfo(sys.argv[1])' "$zone"
mkdir -m 700 private tls data
echo "FT_LAN_IP=$ip" > .env
echo "FT_ZONE=$zone" >> .env
# Match the host account so its owner can back up private files without sudo.
printf 'FT_UID=%s\nFT_GID=%s\n' "$(id -u)" "$(id -g)" >> .env
openssl req -x509 -newkey rsa:3072 -nodes -days 3650 -sha256 \
  -subj "/CN=Familytime Household CA" -addext "basicConstraints=critical,CA:TRUE,pathlen:0" \
  -addext "keyUsage=critical,keyCertSign,cRLSign" -keyout private/ca.key -out household-ca.crt
./renew-cert.sh
./make-client.sh
docker compose build
docker compose run --rm --no-deps dashboard python -m server.admin
docker compose up -d
printf '\nDashboard: https://%s:8443\nPublic trust certificate: household-ca.crt\n' "$ip"
openssl x509 -in household-ca.crt -noout -fingerprint -sha256
